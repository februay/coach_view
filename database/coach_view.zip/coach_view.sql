/*
Navicat MySQL Data Transfer

Source Server         : local-coach_view
Source Server Version : 50561
Source Host           : 127.0.0.1:3306
Source Database       : coach_view

Target Server Type    : MYSQL
Target Server Version : 50561
File Encoding         : 65001

Date: 2018-08-16 08:32:43
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `club`
-- ----------------------------
DROP TABLE IF EXISTS `club`;
CREATE TABLE `club` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `club_id` varchar(255) NOT NULL,
  `club_name` varchar(255) DEFAULT NULL,
  `admin_id` varchar(255) DEFAULT NULL COMMENT '管理员uid',
  `admin_name` varchar(255) DEFAULT NULL COMMENT '管理员姓名',
  `province` varchar(255) DEFAULT NULL COMMENT '省',
  `province_name` varchar(255) DEFAULT NULL COMMENT '省',
  `city` varchar(255) DEFAULT NULL COMMENT '市',
  `city_name` varchar(255) DEFAULT NULL COMMENT '市',
  `region` varchar(255) DEFAULT NULL COMMENT '区',
  `region_name` varchar(255) DEFAULT NULL COMMENT '区',
  `county` varchar(255) DEFAULT NULL COMMENT '县',
  `county_name` varchar(255) DEFAULT NULL COMMENT '县',
  `street` varchar(255) DEFAULT NULL COMMENT '街道',
  `street_name` varchar(255) DEFAULT NULL COMMENT '街道',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '0：无效用户 1：有效, -1 预分配uid用户',
  `create_time` datetime DEFAULT NULL,
  `active_time` datetime DEFAULT NULL COMMENT '激活时间',
  `delete_status` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `club_id` (`club_id`) USING BTREE,
  KEY `admin_id` (`admin_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of club
-- ----------------------------
INSERT INTO `club` VALUES ('1', 'club-1', 'club-1', '47fbf3b1-861a-40fc-826b-d506b17bf7b8', '121xxxx', '11', '北京市', '1101', '市辖区', '110101', '东城区', '县', null, '110101001', '东华门街道办事处', '1', '2018-07-23 11:44:29', '2018-07-23 11:44:29', '0');
INSERT INTO `club` VALUES ('2', '7911829e-5c97-4469-a18f-47358ff1ad46', null, null, null, '12', '天津市', '1201', '1201', '120102', '120102', null, null, '120102002', '120102002', '1', '2018-07-30 21:40:37', '2018-07-30 21:40:37', '1');
INSERT INTO `club` VALUES ('3', 'c2478eeb-827c-4d56-8434-2caaf451e27c', null, null, null, '12', '天津市', '1201', '市辖区', '120102', '河东区', null, null, '120102002', '大直沽街道', '1', '2018-07-30 21:42:46', '2018-07-30 21:42:46', '1');
INSERT INTO `club` VALUES ('4', 'fe23156b-1037-4bcd-b7f6-eca89e03eae5', 'dada', '4416f3dc-bb71-49d8-9c52-ca9d4f2c9c8f', 'test', '11', '北京市', '1101', '市辖区', '110102', '西城区', null, null, '110102003', '新街口街道办事处', '1', '2018-07-30 21:49:58', '2018-07-30 21:49:58', '1');
INSERT INTO `club` VALUES ('5', '4be4423e-e1ab-4f11-901d-c12cb4cece18', 'xx', '4416f3dc-bb71-49d8-9c52-ca9d4f2c9c8f', 'test', '12', '天津市', '1201', '市辖区', '120102', '河东区', null, null, '120102001', '大王庄街道', '1', '2018-07-30 22:06:42', '2018-07-30 22:06:42', '1');
INSERT INTO `club` VALUES ('6', '785a08f0-07a4-421a-b1e0-83df006db932', 'dd', '4416f3dc-bb71-49d8-9c52-ca9d4f2c9c8f', 'test', '11', '北京市', '1101', '市辖区', '110102', '西城区', null, null, '110102003', '新街口街道办事处', '1', '2018-07-30 22:10:29', '2018-07-30 22:10:29', '1');
INSERT INTO `club` VALUES ('7', 'e297711e-12b5-4170-8947-ab423098b4bc', 'dad', '4416f3dc-bb71-49d8-9c52-ca9d4f2c9c8f', 'test', '12', '天津市', '1201', '市辖区', '120101', '和平区', null, null, '120101002', '小白楼街道', '1', '2018-07-30 22:16:52', '2018-07-30 22:16:52', '1');
INSERT INTO `club` VALUES ('8', 'b82a5d52-dd2b-4454-9102-f38a07dfbf34', '131', '4416f3dc-bb71-49d8-9c52-ca9d4f2c9c8f', 'test', '13', '河北省', '1302', '唐山市', '130204', '古冶区', null, null, '130204001', '林西街道办事处', '1', '2018-07-30 22:30:36', '2018-07-30 22:30:36', '1');
INSERT INTO `club` VALUES ('9', '1fb57b9b-dc3c-4113-a26f-d18e25a576a4', 'da', '4416f3dc-bb71-49d8-9c52-ca9d4f2c9c8f', 'test', '12', '天津市', '1201', '市辖区', '120102', '河东区', null, null, '120102001', '大王庄街道', '1', '2018-07-30 22:31:54', '2018-07-30 22:31:54', '1');
INSERT INTO `club` VALUES ('10', '4dd80a03-6519-479d-a979-89af77cfbcb2', 'test', '4416f3dc-bb71-49d8-9c52-ca9d4f2c9c8f', 'test', '13', '河北省', '1304', '邯郸市', '130406', '峰峰矿区', null, null, '130406101', '峰峰镇', '1', '2018-07-30 22:50:58', '2018-07-30 22:50:58', '1');
INSERT INTO `club` VALUES ('11', 'bb9db48c-4262-4fe8-803e-cd7cde35f606', '俱乐部一', '972825f6-e672-4ff7-abce-60fef8a818af', '11', '13', '河北省', '1304', '邯郸市', '130404', '复兴区', null, null, '130404002', '百家村街道办事处', '1', '2018-07-30 22:53:51', '2018-07-30 22:53:51', '0');
INSERT INTO `club` VALUES ('12', '11685c71-3576-4c3c-bc94-a9d4c7132122', '【勿删】皇马俱乐部', '4416f3dc-bb71-49d8-9c52-ca9d4f2c9c8f', 'test', '11', '北京市', '1101', '市辖区', '110101', '东城区', null, null, '110101001', '东华门街道办事处', '1', '2018-07-30 22:56:39', '2018-07-30 22:56:39', '0');
INSERT INTO `club` VALUES ('13', 'f198a147-e8a0-4334-aabd-e4f2eb680e5e', 'xxx', '4416f3dc-bb71-49d8-9c52-ca9d4f2c9c8f', '【勿删】test-club', '11', '北京市', '1101', '市辖区', '110102', '西城区', null, null, '110102001', '西长安街街道办事处', '1', '2018-08-01 23:29:12', '2018-08-01 23:29:12', '1');
INSERT INTO `club` VALUES ('14', '6865270d-24f6-425e-91ec-a71b1c685a80', '11', '61b354ff-02ea-4d98-8159-4dc61958defc', 'ao', '12', '天津市', '1201', '市辖区', '120102', '河东区', null, null, '120102003', '中山门街道', '1', '2018-08-03 21:32:46', '2018-08-03 21:32:46', '1');
INSERT INTO `club` VALUES ('15', 'b79c3d71-ed70-46df-ad4c-e005682495ed', '俱乐部test1', '61b354ff-02ea-4d98-8159-4dc61958defc', 'ao', '12', '天津市', '1201', '市辖区', '120102', '河东区', null, null, '120102001', '大王庄街道', '1', '2018-08-03 21:39:14', '2018-08-03 21:39:14', '1');
INSERT INTO `club` VALUES ('16', 'acea2120-f024-46e4-bc1b-53ba55b26901', '121212121', '61b354ff-02ea-4d98-8159-4dc61958defc', 'ao', '12', '天津市', '1201', '市辖区', '120103', '河西区', null, null, '120103001', '大营门街道', '1', '2018-08-03 21:42:07', '2018-08-03 21:42:07', '1');
INSERT INTO `club` VALUES ('17', '8816fe48-6ca6-43d2-91c3-b1c634f4de79', '11112222', '61b354ff-02ea-4d98-8159-4dc61958defc', 'ao', '13', '河北省', '1303', '秦皇岛市', '130303', '山海关区', null, null, '130303003', '西关街道办事处', '1', '2018-08-03 21:43:42', '2018-08-03 21:43:42', '1');
INSERT INTO `club` VALUES ('18', 'bce8c731-5348-481d-9137-f84c447a7fbd', 'xx', '61b354ff-02ea-4d98-8159-4dc61958defc', 'ao', '12', '天津市', '1201', '市辖区', '120102', '河东区', null, null, '120102003', '中山门街道', '1', '2018-08-03 21:49:53', '2018-08-03 21:49:53', '1');
INSERT INTO `club` VALUES ('19', '8d20950f-88cc-44ed-a333-ad55a72e078d', '运河小学队', '61b354ff-02ea-4d98-8159-4dc61958defc', 'ao', '11', '北京市', '1101', '市辖区', '110101', '东城区', null, null, '110101001', '东华门街道办事处', '1', '2018-08-05 09:31:40', '2018-08-05 09:31:40', '1');
INSERT INTO `club` VALUES ('20', '93c00936-1b1e-41d5-a66c-b251e30d2a95', '三高', 'c42ed1c3-2d6a-44ef-92c1-a0f9fbf97cfd', '12', '11', '北京市', '1101', '市辖区', '110108', '海淀区', null, null, '110108026', '温泉地区办事处', '1', '2018-08-05 16:21:23', '2018-08-05 16:21:23', '0');
INSERT INTO `club` VALUES ('21', '301aab3a-bf95-4208-bd7d-7fd01fb5accf', 'club-2', '240e77d7-8329-459b-8497-1fead433bb52', 'test', '11', '北京市', '1101', '市辖区', '110101', '东城区', null, null, '110101001', '东华门街道办事处', '1', '2018-08-07 14:54:18', '2018-08-07 14:54:18', '0');
INSERT INTO `club` VALUES ('22', '79eb5d6c-ed31-40dd-8131-8d4128309cc5', '测试俱乐部', '240e77d7-8329-459b-8497-1fead433bb52', 'test', '11', '北京市', '1101', '市辖区', '110102', '西城区', null, null, '110102001', '西长安街街道办事处', '1', '2018-08-07 17:38:11', '2018-08-07 17:38:11', '0');

-- ----------------------------
-- Table structure for `match`
-- ----------------------------
DROP TABLE IF EXISTS `match`;
CREATE TABLE `match` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `match_id` varchar(255) NOT NULL,
  `match_number` varchar(64) DEFAULT NULL COMMENT '比赛编号',
  `match_name` varchar(255) DEFAULT NULL,
  `team_id` varchar(255) DEFAULT NULL,
  `match_session` varchar(255) DEFAULT NULL COMMENT '比赛场次',
  `match_time` datetime DEFAULT NULL COMMENT '比赛时间',
  `match_video` varchar(255) DEFAULT NULL COMMENT '比赛视频',
  `creator_id` varchar(255) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `delete_status` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `match_id` (`match_id`) USING BTREE,
  KEY `team_id` (`team_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of match
-- ----------------------------
INSERT INTO `match` VALUES ('1', 'match-1', 'xxx', '20180808', 'team-1', '1', '2018-08-08 00:00:00', 'xxx', '10001', '2018-08-08 19:43:12', '0');
INSERT INTO `match` VALUES ('2', 'a251d7c7-43d4-4600-937b-ff40c54d40dc', 'xxx', '20180808', 'team-1', '1', '2018-08-08 00:00:00', 'xxx', null, '2018-08-10 20:11:08', '0');
INSERT INTO `match` VALUES ('3', '5fdb8336-9ac2-482d-864b-08c741156376', 'xxx', '20180808', 'team-1', '1', '2018-08-08 00:00:00', 'xxx', null, '2018-08-10 20:14:39', '0');
INSERT INTO `match` VALUES ('4', '878c9b36-6f97-4c51-b093-c5f4e3be0e9a', 'xxx', '20180808', 'team-1', '1', '2018-08-08 00:00:00', 'xxx', null, '2018-08-10 20:20:25', '0');
INSERT INTO `match` VALUES ('5', '65efc567-abad-4eaf-b7cb-4bcb065e4991', 'xxx', '20180808', 'team-1', '1', '2018-08-08 00:00:00', 'xxx', null, '2018-08-10 20:21:18', '0');
INSERT INTO `match` VALUES ('6', '05020734-e937-46a9-9dd3-305ac30d48c7', 'xxx', '20180808', 'team-1', '1', '2018-08-08 00:00:00', 'xxx', null, '2018-08-10 20:24:26', '0');
INSERT INTO `match` VALUES ('7', '33905df7-97d3-498a-94e4-8fd079519b5b', 'xxx', '20180808', 'team-1', '1', '2018-08-08 00:00:00', 'xxx', null, '2018-08-10 20:27:45', '0');
INSERT INTO `match` VALUES ('8', '05a6b456-480d-4d6f-b75f-d0495843f406', 'xxx', '20180808', 'team-1', '1', '2018-08-08 00:00:00', 'xxx', null, '2018-08-10 20:29:07', '0');
INSERT INTO `match` VALUES ('9', '00a06cd4-6b6c-42ed-beac-1686e7de6817', 'xxx', '20180808', '66a6ddcb-2be3-493e-aad2-c32280d9e5e1', '1', '2018-08-08 00:00:00', 'xxx', null, '2018-08-11 09:36:47', '0');
INSERT INTO `match` VALUES ('10', '8171567b-b684-47ba-8154-f2801783274b', 'xxx', '20180808', '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', '1', '2018-08-08 00:00:00', 'xxx', null, '2018-08-11 19:56:09', '0');
INSERT INTO `match` VALUES ('11', '2bef97ff-e9d9-4870-9c8b-0f302cbc53f0', 'xxx', '20180808', '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', '1', '2018-08-08 00:00:00', 'xxx', null, '2018-08-11 22:38:51', '0');

-- ----------------------------
-- Table structure for `match_team_info`
-- ----------------------------
DROP TABLE IF EXISTS `match_team_info`;
CREATE TABLE `match_team_info` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `uuid` varchar(64) NOT NULL,
  `match_id` varchar(255) NOT NULL,
  `team_id` varchar(255) NOT NULL,
  `match_session` varchar(255) DEFAULT NULL COMMENT '比赛场次',
  `shoot_count` int(11) DEFAULT NULL COMMENT '射门次数',
  `shoot_target_count` int(11) DEFAULT NULL COMMENT '射正次数',
  `pass_count` int(11) DEFAULT NULL COMMENT '传球次数',
  `pass_success_count` int(11) DEFAULT NULL COMMENT '传球成功次数',
  `pass_success_percentage` decimal(8,4) DEFAULT NULL COMMENT '传球成功率（%）',
  `possession_percentage` decimal(8,4) DEFAULT NULL COMMENT '控球率（%）',
  `running_distance` decimal(8,4) DEFAULT NULL COMMENT '跑动距离',
  `steals` int(11) DEFAULT NULL COMMENT '抢断/扑救次数',
  `goals` tinyint(4) DEFAULT NULL COMMENT '进球数',
  `losses` tinyint(4) DEFAULT NULL,
  `match_result` varchar(4) DEFAULT NULL COMMENT '比赛结果: 1:胜, 0:平, -1:负',
  `opponent` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否对手球队， 0 :  本队数据， 1： 对手球队数据',
  `create_time` datetime DEFAULT NULL,
  `delete_status` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uuid` (`uuid`) USING BTREE,
  KEY `match_id` (`match_id`) USING BTREE,
  KEY `team_id` (`team_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of match_team_info
-- ----------------------------
INSERT INTO `match_team_info` VALUES ('2', '5358071eabdafadfa-fadfa', 'match-1', 'team-1', '1', '6', '3', '189', '161', '85.0000', '45.0000', '37.9000', '18', '1', '0', '胜', '0', '2018-08-10 20:27:45', '0');
INSERT INTO `match_team_info` VALUES ('3', '4b79d8f4-bb7d-4c35-a7e7-5358071eabda', '05a6b456-480d-4d6f-b75f-d0495843f406', 'team-1', '1', '6', '3', '189', '161', '85.0000', '45.0000', '37.9000', '18', '1', '1', '平', '0', '2018-08-10 20:29:07', '0');
INSERT INTO `match_team_info` VALUES ('4', '0d79c310-2e16-49a0-bf35-ef933f6d2ab1', '00a06cd4-6b6c-42ed-beac-1686e7de6817', '66a6ddcb-2be3-493e-aad2-c32280d9e5e1', '1', '6', '3', '189', '161', '85.0000', '45.0000', '37.9000', '18', '1', '0', '胜', '0', '2018-08-11 09:36:47', '0');
INSERT INTO `match_team_info` VALUES ('5', '7d5323d6-fcb5-456f-a7d4-36a1252df40e', '8171567b-b684-47ba-8154-f2801783274b', '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', '1', '6', '3', '189', '161', '85.0000', '45.0000', '37.9000', '18', '1', '0', '胜', '0', '2018-08-11 19:56:09', '0');
INSERT INTO `match_team_info` VALUES ('6', '2625f837-dc46-40ae-ac37-27be8bffa451', '2bef97ff-e9d9-4870-9c8b-0f302cbc53f0', '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', '1', '6', '3', '189', '161', '85.0000', '45.0000', '37.9000', '18', '1', '0', '胜', '0', '2018-08-11 22:38:51', '0');

-- ----------------------------
-- Table structure for `match_team_member_info`
-- ----------------------------
DROP TABLE IF EXISTS `match_team_member_info`;
CREATE TABLE `match_team_member_info` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `uuid` varchar(64) NOT NULL,
  `match_id` varchar(255) NOT NULL,
  `team_id` varchar(255) NOT NULL,
  `member_id` varchar(255) DEFAULT NULL COMMENT '球员id',
  `member_number` varchar(255) DEFAULT NULL COMMENT '球员编号',
  `shoot_count` int(11) DEFAULT NULL COMMENT '射门次数',
  `shoot_target_count` int(11) DEFAULT NULL COMMENT '射正次数',
  `pass_count` int(11) DEFAULT NULL COMMENT '传球次数',
  `pass_success_count` int(11) DEFAULT NULL COMMENT '传球成功次数',
  `pass_success_percentage` decimal(8,4) DEFAULT NULL COMMENT '传球成功率（%）',
  `running_distance` decimal(8,4) DEFAULT NULL COMMENT '跑动距离',
  `steals` int(11) DEFAULT NULL COMMENT '抢断/扑救次数',
  `goals` int(11) DEFAULT NULL COMMENT '进球数',
  `position` varchar(255) DEFAULT NULL COMMENT '位置',
  `create_time` datetime DEFAULT NULL,
  `delete_status` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uuid` (`uuid`) USING BTREE,
  KEY `match_id` (`match_id`) USING BTREE,
  KEY `team_id` (`team_id`) USING BTREE,
  KEY `member_id` (`member_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=109 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of match_team_member_info
-- ----------------------------
INSERT INTO `match_team_member_info` VALUES ('19', '7ddd5b71-6313-4aa3-90b9-b076fd0ca5d1', 'match-1', 'team-1', null, '1', '0', '0', '9', '9', '100.0000', '0.9000', '0', '0', null, '2018-08-10 20:27:45', '0');
INSERT INTO `match_team_member_info` VALUES ('20', 'e8ae2040-9672-4183-a05f-bfd6f267a2eb', 'match-1', 'team-1', null, '2', '0', '0', '21', '21', '81.0000', '3.1000', '0', '0', null, '2018-08-10 20:27:45', '0');
INSERT INTO `match_team_member_info` VALUES ('21', 'bae4eecd-9564-42bf-b4b1-d8c65ed32703', 'match-1', 'team-1', null, '3', '0', '0', '16', '16', '81.3000', '2.1000', '0', '0', null, '2018-08-10 20:27:45', '0');
INSERT INTO `match_team_member_info` VALUES ('22', '0adc5712-9832-4522-92d0-44af106ddd4d', 'match-1', 'team-1', null, '4', '0', '0', '16', '16', '81.3000', '2.1000', '0', '0', null, '2018-08-10 20:27:45', '0');
INSERT INTO `match_team_member_info` VALUES ('23', '0e7126cf-1c44-4df3-a02b-c5cda5f45fe5', 'match-1', 'team-1', null, '5', '2', '1', '28', '28', '92.9000', '3.2000', '1', '0', null, '2018-08-10 20:27:45', '0');
INSERT INTO `match_team_member_info` VALUES ('24', 'a49b17bf-bb8e-4fae-844f-103d32730da9', 'match-1', 'team-1', null, '6', '2', '2', '14', '14', '85.7000', '2.0000', '2', '1', null, '2018-08-10 20:27:45', '0');
INSERT INTO `match_team_member_info` VALUES ('25', '403d8b68-b6eb-4fa5-a685-d39c2a15c53d', 'match-1', 'team-1', null, '7', '0', '0', '20', '20', '75.0000', '2.7000', '0', '0', null, '2018-08-10 20:27:45', '0');
INSERT INTO `match_team_member_info` VALUES ('26', 'fa491533-e034-4425-8936-6546ee26f2b9', 'match-1', 'team-1', null, '8', '3', '1', '20', '20', '90.0000', '2.7000', '1', '0', null, '2018-08-10 20:27:45', '0');
INSERT INTO `match_team_member_info` VALUES ('27', '32a94262-4c5a-427f-81f2-e3d7eb4d4171', 'match-1', 'team-1', null, '10', '0', '0', '21', '21', '85.7000', '3.3000', '0', '0', null, '2018-08-10 20:27:45', '0');
INSERT INTO `match_team_member_info` VALUES ('28', 'e2b5da84-4009-4a67-b721-7cf1723a29b1', 'match-1', 'team-1', null, '11', '1', '1', '19', '19', '94.7000', '1.9000', '1', '0', null, '2018-08-10 20:27:45', '0');
INSERT INTO `match_team_member_info` VALUES ('29', 'fa3afb53-2a3e-4281-a148-662e3e1717c2', 'match-1', 'team-1', null, '12', '0', '0', '19', '19', '94.7000', '1.9000', '0', '0', null, '2018-08-10 20:27:45', '0');
INSERT INTO `match_team_member_info` VALUES ('30', '5a203171-6041-4fe0-8310-42b73d707a07', 'match-1', 'team-1', null, '13', '0', '0', '19', '19', '94.7000', '1.9000', '0', '0', null, '2018-08-10 20:27:45', '0');
INSERT INTO `match_team_member_info` VALUES ('31', '17f2d2fe-cf0d-459e-9fc2-610144c3749f', 'match-1', 'team-1', null, '15', '0', '0', '16', '16', '75.0000', '1.9000', '0', '0', null, '2018-08-10 20:27:45', '0');
INSERT INTO `match_team_member_info` VALUES ('32', '6516a8fd-fa2f-448a-b669-63d6ce7dae14', 'match-1', 'team-1', null, '16', '0', '0', '16', '16', '81.3000', '1.9000', '0', '0', null, '2018-08-10 20:27:45', '0');
INSERT INTO `match_team_member_info` VALUES ('33', 'b5d3a02f-66f7-45bb-af84-be57890ad48b', 'match-1', 'team-1', null, '17', '0', '0', '16', '16', '81.3000', '2.5000', '0', '0', null, '2018-08-10 20:27:45', '0');
INSERT INTO `match_team_member_info` VALUES ('34', 'b4fc2c15-637a-4519-b651-5ea5ebee64a8', 'match-1', 'team-1', null, '18', '1', '0', '13', '13', '76.9000', '1.9000', '0', '0', null, '2018-08-10 20:27:45', '0');
INSERT INTO `match_team_member_info` VALUES ('35', 'dde4fbf3-ea3f-40f6-b18d-edfd6cc10d51', 'match-1', 'team-1', null, '19', '0', '0', '5', '5', '100.0000', '0.8000', '0', '0', null, '2018-08-10 20:27:45', '0');
INSERT INTO `match_team_member_info` VALUES ('36', 'bc243096-4116-4b53-b958-3cb2595f0006', 'match-1', 'team-1', null, '20', '1', '1', '10', '10', '70.0000', '1.3000', '1', '0', null, '2018-08-10 20:27:45', '0');
INSERT INTO `match_team_member_info` VALUES ('37', '1fb9cce5-2e08-462c-92a3-d140879bf8d8', '05a6b456-480d-4d6f-b75f-d0495843f406', 'team-1', null, '1', '0', '0', '9', '9', '100.0000', '0.9000', '0', '0', null, '2018-08-10 20:29:07', '0');
INSERT INTO `match_team_member_info` VALUES ('38', '84c2b792-87f0-4186-a4e1-d4195e4da3b9', '05a6b456-480d-4d6f-b75f-d0495843f406', 'team-1', null, '2', '0', '0', '21', '21', '81.0000', '3.1000', '0', '0', null, '2018-08-10 20:29:07', '0');
INSERT INTO `match_team_member_info` VALUES ('39', '28da1243-6d7c-4152-bacc-9552dd878729', '05a6b456-480d-4d6f-b75f-d0495843f406', 'team-1', null, '3', '0', '0', '16', '16', '81.3000', '2.1000', '0', '0', null, '2018-08-10 20:29:07', '0');
INSERT INTO `match_team_member_info` VALUES ('40', '9ed259a5-8c09-4141-95ec-87848583d2ce', '05a6b456-480d-4d6f-b75f-d0495843f406', 'team-1', null, '4', '0', '0', '16', '16', '81.3000', '2.1000', '0', '0', null, '2018-08-10 20:29:07', '0');
INSERT INTO `match_team_member_info` VALUES ('41', '1cba63b2-3876-4856-aa0c-d7dcd573b0b5', '05a6b456-480d-4d6f-b75f-d0495843f406', 'team-1', null, '5', '2', '1', '28', '28', '92.9000', '3.2000', '1', '0', null, '2018-08-10 20:29:07', '0');
INSERT INTO `match_team_member_info` VALUES ('42', '3cacc6cf-328a-4760-a005-b56d485bc649', '05a6b456-480d-4d6f-b75f-d0495843f406', 'team-1', null, '6', '2', '2', '14', '14', '85.7000', '2.0000', '2', '1', null, '2018-08-10 20:29:07', '0');
INSERT INTO `match_team_member_info` VALUES ('43', '6f8f695f-a01d-4109-9279-4f88d0c2cdaf', '05a6b456-480d-4d6f-b75f-d0495843f406', 'team-1', null, '7', '0', '0', '20', '20', '75.0000', '2.7000', '0', '0', null, '2018-08-10 20:29:07', '0');
INSERT INTO `match_team_member_info` VALUES ('44', 'f450f9aa-d797-4ac4-b613-4282e21b5f72', '05a6b456-480d-4d6f-b75f-d0495843f406', 'team-1', null, '8', '3', '1', '20', '20', '90.0000', '2.7000', '1', '0', null, '2018-08-10 20:29:07', '0');
INSERT INTO `match_team_member_info` VALUES ('45', '991f5add-c4e0-44f6-a60f-fd30e4797646', '05a6b456-480d-4d6f-b75f-d0495843f406', 'team-1', null, '10', '0', '0', '21', '21', '85.7000', '3.3000', '0', '0', null, '2018-08-10 20:29:07', '0');
INSERT INTO `match_team_member_info` VALUES ('46', '9e154c41-e5e3-43b8-b27a-bbeeece276ed', '05a6b456-480d-4d6f-b75f-d0495843f406', 'team-1', null, '11', '1', '1', '19', '19', '94.7000', '1.9000', '1', '0', null, '2018-08-10 20:29:07', '0');
INSERT INTO `match_team_member_info` VALUES ('47', '826f8f74-869f-42b6-9113-79e903074693', '05a6b456-480d-4d6f-b75f-d0495843f406', 'team-1', null, '12', '0', '0', '19', '19', '94.7000', '1.9000', '0', '0', null, '2018-08-10 20:29:07', '0');
INSERT INTO `match_team_member_info` VALUES ('48', '869ca5fe-4d60-4709-8c2e-1098b1e4abac', '05a6b456-480d-4d6f-b75f-d0495843f406', 'team-1', null, '13', '0', '0', '19', '19', '94.7000', '1.9000', '0', '0', null, '2018-08-10 20:29:07', '0');
INSERT INTO `match_team_member_info` VALUES ('49', 'eead0b58-8922-49c4-b507-cabdf27c6205', '05a6b456-480d-4d6f-b75f-d0495843f406', 'team-1', null, '15', '0', '0', '16', '16', '75.0000', '1.9000', '0', '0', null, '2018-08-10 20:29:07', '0');
INSERT INTO `match_team_member_info` VALUES ('50', 'a6dc5df7-1e59-4050-88f9-9213bd4dd7e8', '05a6b456-480d-4d6f-b75f-d0495843f406', 'team-1', null, '16', '0', '0', '16', '16', '81.3000', '1.9000', '0', '0', null, '2018-08-10 20:29:07', '0');
INSERT INTO `match_team_member_info` VALUES ('51', '7a802433-65a4-452c-8846-057ab320d066', '05a6b456-480d-4d6f-b75f-d0495843f406', 'team-1', null, '17', '0', '0', '16', '16', '81.3000', '2.5000', '0', '0', null, '2018-08-10 20:29:07', '0');
INSERT INTO `match_team_member_info` VALUES ('52', '10ed3c71-9477-447f-b345-4bb49820abeb', '05a6b456-480d-4d6f-b75f-d0495843f406', 'team-1', null, '18', '1', '0', '13', '13', '76.9000', '1.9000', '0', '0', null, '2018-08-10 20:29:07', '0');
INSERT INTO `match_team_member_info` VALUES ('53', 'e75014af-6cd1-42a4-9a06-7dc86cb51507', '05a6b456-480d-4d6f-b75f-d0495843f406', 'team-1', null, '19', '0', '0', '5', '5', '100.0000', '0.8000', '0', '0', null, '2018-08-10 20:29:07', '0');
INSERT INTO `match_team_member_info` VALUES ('54', '6c325f5f-cec3-4678-ae24-c27ac9bec0ad', '05a6b456-480d-4d6f-b75f-d0495843f406', 'team-1', null, '20', '1', '1', '10', '10', '70.0000', '1.3000', '1', '0', null, '2018-08-10 20:29:07', '0');
INSERT INTO `match_team_member_info` VALUES ('55', 'd4ae3e13-bd3f-4a2b-b517-6113b2c2830c', '00a06cd4-6b6c-42ed-beac-1686e7de6817', '66a6ddcb-2be3-493e-aad2-c32280d9e5e1', null, '1', '0', '0', '9', '9', '100.0000', '0.9000', '0', '0', null, '2018-08-11 09:36:47', '0');
INSERT INTO `match_team_member_info` VALUES ('56', 'bb39f375-a204-46c8-b503-147c3ff1cf9c', '00a06cd4-6b6c-42ed-beac-1686e7de6817', '66a6ddcb-2be3-493e-aad2-c32280d9e5e1', null, '2', '0', '0', '21', '21', '81.0000', '3.1000', '0', '0', null, '2018-08-11 09:36:47', '0');
INSERT INTO `match_team_member_info` VALUES ('57', 'eb1200e3-5db0-4703-9761-d186d790fc29', '00a06cd4-6b6c-42ed-beac-1686e7de6817', '66a6ddcb-2be3-493e-aad2-c32280d9e5e1', null, '3', '0', '0', '16', '16', '81.3000', '2.1000', '0', '0', null, '2018-08-11 09:36:47', '0');
INSERT INTO `match_team_member_info` VALUES ('58', '24611007-73d9-4518-8b81-206ff5f2c5c1', '00a06cd4-6b6c-42ed-beac-1686e7de6817', '66a6ddcb-2be3-493e-aad2-c32280d9e5e1', null, '4', '0', '0', '16', '16', '81.3000', '2.1000', '0', '0', null, '2018-08-11 09:36:47', '0');
INSERT INTO `match_team_member_info` VALUES ('59', '34c24517-b3c2-4743-b88a-0329ad47894d', '00a06cd4-6b6c-42ed-beac-1686e7de6817', '66a6ddcb-2be3-493e-aad2-c32280d9e5e1', null, '5', '2', '1', '28', '28', '92.9000', '3.2000', '1', '0', null, '2018-08-11 09:36:47', '0');
INSERT INTO `match_team_member_info` VALUES ('60', '21b775ab-c0ab-4673-af6c-6d80bb8b51b5', '00a06cd4-6b6c-42ed-beac-1686e7de6817', '66a6ddcb-2be3-493e-aad2-c32280d9e5e1', null, '6', '2', '2', '14', '14', '85.7000', '2.0000', '2', '1', null, '2018-08-11 09:36:47', '0');
INSERT INTO `match_team_member_info` VALUES ('61', '39a0c05d-5009-4979-8cf0-353b54e58cbb', '00a06cd4-6b6c-42ed-beac-1686e7de6817', '66a6ddcb-2be3-493e-aad2-c32280d9e5e1', null, '7', '0', '0', '20', '20', '75.0000', '2.7000', '0', '0', null, '2018-08-11 09:36:47', '0');
INSERT INTO `match_team_member_info` VALUES ('62', '1bcb7b31-b481-4c35-8c45-1c4b3d515c82', '00a06cd4-6b6c-42ed-beac-1686e7de6817', '66a6ddcb-2be3-493e-aad2-c32280d9e5e1', null, '8', '3', '1', '20', '20', '90.0000', '2.7000', '1', '0', null, '2018-08-11 09:36:47', '0');
INSERT INTO `match_team_member_info` VALUES ('63', 'dda84a24-06e1-49fd-bb84-1b1d12759d84', '00a06cd4-6b6c-42ed-beac-1686e7de6817', '66a6ddcb-2be3-493e-aad2-c32280d9e5e1', null, '10', '0', '0', '21', '21', '85.7000', '3.3000', '0', '0', null, '2018-08-11 09:36:47', '0');
INSERT INTO `match_team_member_info` VALUES ('64', '13e93ec8-e431-4b79-a9af-c21f6f448421', '00a06cd4-6b6c-42ed-beac-1686e7de6817', '66a6ddcb-2be3-493e-aad2-c32280d9e5e1', null, '11', '1', '1', '19', '19', '94.7000', '1.9000', '1', '0', null, '2018-08-11 09:36:47', '0');
INSERT INTO `match_team_member_info` VALUES ('65', 'f0907a0f-2557-4cc8-9100-462c0df0a547', '00a06cd4-6b6c-42ed-beac-1686e7de6817', '66a6ddcb-2be3-493e-aad2-c32280d9e5e1', null, '12', '0', '0', '19', '19', '94.7000', '1.9000', '0', '0', null, '2018-08-11 09:36:47', '0');
INSERT INTO `match_team_member_info` VALUES ('66', '1eacbb75-9cda-40be-8d64-8735548d3797', '00a06cd4-6b6c-42ed-beac-1686e7de6817', '66a6ddcb-2be3-493e-aad2-c32280d9e5e1', null, '13', '0', '0', '19', '19', '94.7000', '1.9000', '0', '0', null, '2018-08-11 09:36:47', '0');
INSERT INTO `match_team_member_info` VALUES ('67', '3d2c368e-352e-4095-8f5a-c6089d0c5872', '00a06cd4-6b6c-42ed-beac-1686e7de6817', '66a6ddcb-2be3-493e-aad2-c32280d9e5e1', null, '15', '0', '0', '16', '16', '75.0000', '1.9000', '0', '0', null, '2018-08-11 09:36:47', '0');
INSERT INTO `match_team_member_info` VALUES ('68', '606238ef-3923-407f-94f8-558695be4242', '00a06cd4-6b6c-42ed-beac-1686e7de6817', '66a6ddcb-2be3-493e-aad2-c32280d9e5e1', null, '16', '0', '0', '16', '16', '81.3000', '1.9000', '0', '0', null, '2018-08-11 09:36:48', '0');
INSERT INTO `match_team_member_info` VALUES ('69', 'b5d1bf23-48be-4d34-bb70-1b29d27484ec', '00a06cd4-6b6c-42ed-beac-1686e7de6817', '66a6ddcb-2be3-493e-aad2-c32280d9e5e1', null, '17', '0', '0', '16', '16', '81.3000', '2.5000', '0', '0', null, '2018-08-11 09:36:48', '0');
INSERT INTO `match_team_member_info` VALUES ('70', 'e9c25207-235c-4e91-b4a7-b53b79a1e8f6', '00a06cd4-6b6c-42ed-beac-1686e7de6817', '66a6ddcb-2be3-493e-aad2-c32280d9e5e1', null, '18', '1', '0', '13', '13', '76.9000', '1.9000', '0', '0', null, '2018-08-11 09:36:48', '0');
INSERT INTO `match_team_member_info` VALUES ('71', '1ff4bf5b-765d-42e4-83cf-e715c956dfad', '00a06cd4-6b6c-42ed-beac-1686e7de6817', '66a6ddcb-2be3-493e-aad2-c32280d9e5e1', null, '19', '0', '0', '5', '5', '100.0000', '0.8000', '0', '0', null, '2018-08-11 09:36:48', '0');
INSERT INTO `match_team_member_info` VALUES ('72', 'd3beebb5-dea2-4278-b8b2-4d8f6e11a1b0', '00a06cd4-6b6c-42ed-beac-1686e7de6817', '66a6ddcb-2be3-493e-aad2-c32280d9e5e1', null, '20', '1', '1', '10', '10', '70.0000', '1.3000', '1', '0', null, '2018-08-11 09:36:48', '0');
INSERT INTO `match_team_member_info` VALUES ('73', '4300692f-48bf-4261-9051-738ab0335ae3', '8171567b-b684-47ba-8154-f2801783274b', '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', null, '1', '0', '0', '9', '9', '100.0000', '0.9000', '0', '0', null, '2018-08-11 19:56:09', '0');
INSERT INTO `match_team_member_info` VALUES ('74', 'c6211507-816d-4754-8033-05a77c3b1e95', '8171567b-b684-47ba-8154-f2801783274b', '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', null, '2', '0', '0', '21', '21', '81.0000', '3.1000', '0', '0', null, '2018-08-11 19:56:09', '0');
INSERT INTO `match_team_member_info` VALUES ('75', 'a8ea0c02-14b1-4525-acfe-710de560ba3f', '8171567b-b684-47ba-8154-f2801783274b', '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', null, '3', '0', '0', '16', '16', '81.3000', '2.1000', '0', '0', null, '2018-08-11 19:56:09', '0');
INSERT INTO `match_team_member_info` VALUES ('76', 'b2f37c34-87fc-4f19-a999-e095e2f16c15', '8171567b-b684-47ba-8154-f2801783274b', '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', null, '4', '0', '0', '16', '16', '81.3000', '2.1000', '0', '0', null, '2018-08-11 19:56:09', '0');
INSERT INTO `match_team_member_info` VALUES ('77', '48626281-236d-4fc8-8c2a-0d4e9c729f47', '8171567b-b684-47ba-8154-f2801783274b', '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', null, '5', '2', '1', '28', '28', '92.9000', '3.2000', '1', '0', null, '2018-08-11 19:56:09', '0');
INSERT INTO `match_team_member_info` VALUES ('78', '2ebe0275-b3c3-4965-8f08-1bf09f09c8c8', '8171567b-b684-47ba-8154-f2801783274b', '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', null, '6', '2', '2', '14', '14', '85.7000', '2.0000', '2', '1', null, '2018-08-11 19:56:09', '0');
INSERT INTO `match_team_member_info` VALUES ('79', '813bc280-6208-49a7-8a94-fef2e212e919', '8171567b-b684-47ba-8154-f2801783274b', '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', null, '7', '0', '0', '20', '20', '75.0000', '2.7000', '0', '0', null, '2018-08-11 19:56:09', '0');
INSERT INTO `match_team_member_info` VALUES ('80', '1abb0f2c-4034-485a-af37-11b47788d935', '8171567b-b684-47ba-8154-f2801783274b', '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', null, '8', '3', '1', '20', '20', '90.0000', '2.7000', '1', '0', null, '2018-08-11 19:56:09', '0');
INSERT INTO `match_team_member_info` VALUES ('81', '9b788d02-aace-4e31-86fa-1eeb000078de', '8171567b-b684-47ba-8154-f2801783274b', '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', null, '10', '0', '0', '21', '21', '85.7000', '3.3000', '0', '0', null, '2018-08-11 19:56:09', '0');
INSERT INTO `match_team_member_info` VALUES ('82', '3bc19598-0af7-49ba-b1e4-2f63a971cc52', '8171567b-b684-47ba-8154-f2801783274b', '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', null, '11', '1', '1', '19', '19', '94.7000', '1.9000', '1', '0', null, '2018-08-11 19:56:09', '0');
INSERT INTO `match_team_member_info` VALUES ('83', 'b094f1c1-c0d2-4b6c-b42e-aafa1605f96a', '8171567b-b684-47ba-8154-f2801783274b', '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', null, '12', '0', '0', '19', '19', '94.7000', '1.9000', '0', '0', null, '2018-08-11 19:56:09', '0');
INSERT INTO `match_team_member_info` VALUES ('84', 'c7598ddf-2fed-4064-8961-be8cc0946a09', '8171567b-b684-47ba-8154-f2801783274b', '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', null, '13', '0', '0', '19', '19', '94.7000', '1.9000', '0', '0', null, '2018-08-11 19:56:09', '0');
INSERT INTO `match_team_member_info` VALUES ('85', 'd4b264b9-a4f5-401d-957a-e35852f1646e', '8171567b-b684-47ba-8154-f2801783274b', '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', null, '15', '0', '0', '16', '16', '75.0000', '1.9000', '0', '0', null, '2018-08-11 19:56:09', '0');
INSERT INTO `match_team_member_info` VALUES ('86', 'fc79f084-f865-44cf-8f1a-eabbacd58441', '8171567b-b684-47ba-8154-f2801783274b', '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', null, '16', '0', '0', '16', '16', '81.3000', '1.9000', '0', '0', null, '2018-08-11 19:56:09', '0');
INSERT INTO `match_team_member_info` VALUES ('87', '56dd60f5-711e-4a03-9ffc-3b3fdcf39391', '8171567b-b684-47ba-8154-f2801783274b', '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', null, '17', '0', '0', '16', '16', '81.3000', '2.5000', '0', '0', null, '2018-08-11 19:56:09', '0');
INSERT INTO `match_team_member_info` VALUES ('88', '02b422c2-7216-4378-9e01-9bbfaea400cc', '8171567b-b684-47ba-8154-f2801783274b', '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', null, '18', '1', '0', '13', '13', '76.9000', '1.9000', '0', '0', null, '2018-08-11 19:56:09', '0');
INSERT INTO `match_team_member_info` VALUES ('89', '1656c5f8-b098-4af5-be6f-c238a95c7aaa', '8171567b-b684-47ba-8154-f2801783274b', '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', null, '19', '0', '0', '5', '5', '100.0000', '0.8000', '0', '0', null, '2018-08-11 19:56:09', '0');
INSERT INTO `match_team_member_info` VALUES ('90', '9faa6da6-b2aa-4cfc-b306-25ff5fee5dbf', '8171567b-b684-47ba-8154-f2801783274b', '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', null, '20', '1', '1', '10', '10', '70.0000', '1.3000', '1', '0', null, '2018-08-11 19:56:09', '0');
INSERT INTO `match_team_member_info` VALUES ('91', 'dacc33b9-88c6-43af-9679-ba292cc662a9', '2bef97ff-e9d9-4870-9c8b-0f302cbc53f0', '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', null, '1', '0', '0', '9', '9', '100.0000', '0.9000', '0', '0', null, '2018-08-11 22:38:51', '0');
INSERT INTO `match_team_member_info` VALUES ('92', '19725863-a332-428e-9efa-31c424e09f59', '2bef97ff-e9d9-4870-9c8b-0f302cbc53f0', '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', null, '2', '0', '0', '21', '21', '81.0000', '3.1000', '0', '0', null, '2018-08-11 22:38:51', '0');
INSERT INTO `match_team_member_info` VALUES ('93', '81938a88-d322-498d-b39c-96a3df32828a', '2bef97ff-e9d9-4870-9c8b-0f302cbc53f0', '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', null, '3', '0', '0', '16', '16', '81.3000', '2.1000', '0', '0', null, '2018-08-11 22:38:51', '0');
INSERT INTO `match_team_member_info` VALUES ('94', '1da4590e-3c88-4bf5-9656-a0336e1d6c76', '2bef97ff-e9d9-4870-9c8b-0f302cbc53f0', '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', null, '4', '0', '0', '16', '16', '81.3000', '2.1000', '0', '0', null, '2018-08-11 22:38:51', '0');
INSERT INTO `match_team_member_info` VALUES ('95', '83d9b750-d024-4450-b219-f2670b40279e', '2bef97ff-e9d9-4870-9c8b-0f302cbc53f0', '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', null, '5', '2', '1', '28', '28', '92.9000', '3.2000', '1', '0', null, '2018-08-11 22:38:51', '0');
INSERT INTO `match_team_member_info` VALUES ('96', 'f57a8cf6-4536-4794-bfef-2cec4705d6f9', '2bef97ff-e9d9-4870-9c8b-0f302cbc53f0', '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', null, '6', '2', '2', '14', '14', '85.7000', '2.0000', '2', '1', null, '2018-08-11 22:38:51', '0');
INSERT INTO `match_team_member_info` VALUES ('97', '86683024-8728-422b-b351-a6e5496682b3', '2bef97ff-e9d9-4870-9c8b-0f302cbc53f0', '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', null, '7', '0', '0', '20', '20', '75.0000', '2.7000', '0', '0', null, '2018-08-11 22:38:51', '0');
INSERT INTO `match_team_member_info` VALUES ('98', 'cec40330-2267-48fd-a870-83aea87a739d', '2bef97ff-e9d9-4870-9c8b-0f302cbc53f0', '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', null, '8', '3', '1', '20', '20', '90.0000', '2.7000', '1', '0', null, '2018-08-11 22:38:51', '0');
INSERT INTO `match_team_member_info` VALUES ('99', '4f426202-b5cc-4a4e-9c06-da399c753f32', '2bef97ff-e9d9-4870-9c8b-0f302cbc53f0', '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', null, '10', '0', '0', '21', '21', '85.7000', '3.3000', '0', '0', null, '2018-08-11 22:38:51', '0');
INSERT INTO `match_team_member_info` VALUES ('100', '16268fb1-71cc-4200-a4b9-2422f181d669', '2bef97ff-e9d9-4870-9c8b-0f302cbc53f0', '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', null, '11', '1', '1', '19', '19', '94.7000', '1.9000', '1', '0', null, '2018-08-11 22:38:51', '0');
INSERT INTO `match_team_member_info` VALUES ('101', '70fae425-713f-4a7b-a181-26d5ae645a3c', '2bef97ff-e9d9-4870-9c8b-0f302cbc53f0', '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', null, '12', '0', '0', '19', '19', '94.7000', '1.9000', '0', '0', null, '2018-08-11 22:38:51', '0');
INSERT INTO `match_team_member_info` VALUES ('102', 'aa5f8c99-97be-4745-a9e4-dcaf1bf84332', '2bef97ff-e9d9-4870-9c8b-0f302cbc53f0', '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', null, '13', '0', '0', '19', '19', '94.7000', '1.9000', '0', '0', null, '2018-08-11 22:38:51', '0');
INSERT INTO `match_team_member_info` VALUES ('103', '87432b98-eb38-4051-9d53-c200b6c25fb4', '2bef97ff-e9d9-4870-9c8b-0f302cbc53f0', '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', null, '15', '0', '0', '16', '16', '75.0000', '1.9000', '0', '0', null, '2018-08-11 22:38:51', '0');
INSERT INTO `match_team_member_info` VALUES ('104', 'd471fb63-a655-46f8-87a9-fed4d15b16ba', '2bef97ff-e9d9-4870-9c8b-0f302cbc53f0', '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', null, '16', '0', '0', '16', '16', '81.3000', '1.9000', '0', '0', null, '2018-08-11 22:38:51', '0');
INSERT INTO `match_team_member_info` VALUES ('105', 'b17159f0-94fb-43df-98a0-6c64aae82037', '2bef97ff-e9d9-4870-9c8b-0f302cbc53f0', '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', null, '17', '0', '0', '16', '16', '81.3000', '2.5000', '0', '0', null, '2018-08-11 22:38:51', '0');
INSERT INTO `match_team_member_info` VALUES ('106', 'e4cdc295-2b99-40f2-9fb9-64da9daf3c09', '2bef97ff-e9d9-4870-9c8b-0f302cbc53f0', '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', null, '18', '1', '0', '13', '13', '76.9000', '1.9000', '0', '0', null, '2018-08-11 22:38:51', '0');
INSERT INTO `match_team_member_info` VALUES ('107', 'cf1420a6-d1e8-4e75-9ffd-429fa3e90b5c', '2bef97ff-e9d9-4870-9c8b-0f302cbc53f0', '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', null, '19', '0', '0', '5', '5', '100.0000', '0.8000', '0', '0', null, '2018-08-11 22:38:51', '0');
INSERT INTO `match_team_member_info` VALUES ('108', '1daaade4-09ee-4109-95ee-7763feb8c4e2', '2bef97ff-e9d9-4870-9c8b-0f302cbc53f0', '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', null, '20', '1', '1', '10', '10', '70.0000', '1.3000', '1', '0', null, '2018-08-11 22:38:51', '0');

-- ----------------------------
-- Table structure for `school`
-- ----------------------------
DROP TABLE IF EXISTS `school`;
CREATE TABLE `school` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `school_id` varchar(255) NOT NULL,
  `school_name` varchar(255) DEFAULT NULL,
  `club_id` varchar(255) NOT NULL,
  `club_name` varchar(255) DEFAULT NULL,
  `admin_id` varchar(255) DEFAULT NULL COMMENT '管理员uid',
  `admin_name` varchar(255) DEFAULT NULL COMMENT '管理员姓名',
  `province` varchar(255) DEFAULT NULL COMMENT '省',
  `province_name` varchar(255) DEFAULT NULL COMMENT '省',
  `city` varchar(255) DEFAULT NULL COMMENT '市',
  `city_name` varchar(255) DEFAULT NULL COMMENT '市',
  `region` varchar(255) DEFAULT NULL COMMENT '区',
  `region_name` varchar(255) DEFAULT NULL COMMENT '区',
  `county` varchar(255) DEFAULT NULL COMMENT '县',
  `county_name` varchar(255) DEFAULT NULL COMMENT '县',
  `street` varchar(255) DEFAULT NULL COMMENT '街道',
  `street_name` varchar(255) DEFAULT NULL COMMENT '街道',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '0：无效用户 1：有效, -1 预分配uid用户',
  `create_time` datetime DEFAULT NULL,
  `active_time` datetime DEFAULT NULL COMMENT '激活时间',
  `delete_status` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `school_id` (`school_id`) USING BTREE,
  KEY `admin_id` (`admin_id`) USING BTREE,
  KEY `club_id` (`club_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of school
-- ----------------------------
INSERT INTO `school` VALUES ('2', '504601dd-608a-4bd8-8805-b8db59b07d32', 'string', 'string', 'string', 'string', 'string', 'string', null, 'string', null, 'string', null, 'string', null, null, null, '1', '2018-07-16 15:59:43', '2018-07-16 15:59:43', '0');
INSERT INTO `school` VALUES ('3', 'school-1', 'school-1', 'club-1', 'club-1', '10001', '1', '北京市', null, '北京市', null, '海淀区', null, '中国', null, null, null, '1', '2018-07-23 12:09:00', '2018-07-23 12:09:00', '1');
INSERT INTO `school` VALUES ('4', '8324875e-8033-4f03-8d63-92184227f37d', 'ooo', '348b14ba-13ba-4083-a193-7ac4695541fd', 'dad', '4416f3dc-bb71-49d8-9c52-ca9d4f2c9c8f', 'test', '12', '天津市', '1201', '1201', '120102', '120102', null, null, '120102002', '120102002', '1', '2018-07-30 22:18:15', '2018-07-30 22:18:15', '0');
INSERT INTO `school` VALUES ('5', '1b4dd85b-a401-46bc-80c4-dde891fdc827', 'ada', 'a4b8f77d-5f7d-45fe-a93f-18dbbd4f609b', '131', '4416f3dc-bb71-49d8-9c52-ca9d4f2c9c8f', 'test', '12', '天津市', '1201', '市辖区', '120102', '河东区', null, null, '120102001', '大王庄街道', '1', '2018-07-30 22:30:48', '2018-07-30 22:30:48', '0');
INSERT INTO `school` VALUES ('6', '2e454272-e529-42dc-ae44-12c5782d876c', '3131', '4ae559a0-dc61-4dc6-83db-9ca93f8ff752', 'da', '4416f3dc-bb71-49d8-9c52-ca9d4f2c9c8f', 'test', '15', '内蒙古自治区', '1502', '包头市', '150204', '青山区', null, null, '150204002', '幸福路街道办事处', '1', '2018-07-30 22:32:03', '2018-07-30 22:32:03', '0');
INSERT INTO `school` VALUES ('7', 'eaa2af36-d57d-46a1-9a6c-0350ae80815d', '1dadad', 'bb9db48c-4262-4fe8-803e-cd7cde35f606', 'dada', '4416f3dc-bb71-49d8-9c52-ca9d4f2c9c8f', 'test', '14', '山西省', '1402', '大同市', '140203', '矿区', null, null, '140203002', '新平旺街道办事处', '1', '2018-07-30 22:54:55', '2018-07-30 22:54:55', '1');
INSERT INTO `school` VALUES ('8', '8424fc2c-665c-418d-b348-900545039c1f', '学校测试12222', '11685c71-3576-4c3c-bc94-a9d4c7132122', 'yy', '4416f3dc-bb71-49d8-9c52-ca9d4f2c9c8f', 'test', '11', '北京市', '1101', '市辖区', '110102', '西城区', null, null, '110102001', '西长安街街道办事处', '1', '2018-07-30 22:57:51', '2018-07-30 22:57:51', '1');
INSERT INTO `school` VALUES ('9', 'babf588f-8da3-40d6-82ca-e5be37de8ffb', '辉煌国际', 'bb9db48c-4262-4fe8-803e-cd7cde35f606', '俱乐部一', '7afbaddd-4b9e-4794-abfd-6a0a191a53fd', '刘总1', '11', '北京市', '1101', '市辖区', '110108', '海淀区', null, null, '110108030', '上庄地区办事处', '1', '2018-07-31 09:35:40', '2018-07-31 09:35:40', '0');
INSERT INTO `school` VALUES ('10', '07f4a2ae-8c70-4225-8ac8-739554ab6cbc', '1212', 'club-1', 'club-1', '10002', 'A', '11', '北京市', '1101', '市辖区', '110101', '东城区', null, null, '110101001', '东华门街道办事处', '1', '2018-07-31 17:33:31', '2018-07-31 17:33:31', '0');
INSERT INTO `school` VALUES ('11', 'b362c541-8e15-4cdc-b550-08e30f55d39c', 'xaxaxaxa', '11685c71-3576-4c3c-bc94-a9d4c7132122', 'yy', '4416f3dc-bb71-49d8-9c52-ca9d4f2c9c8f', '【勿删】test-club', '11', '北京市', '1101', '市辖区', '110102', '西城区', null, null, '110102001', '西长安街街道办事处', '1', '2018-08-01 22:48:54', '2018-08-01 22:48:54', '1');
INSERT INTO `school` VALUES ('12', '36ddda30-1c4e-4c91-b713-c3cf87a7867f', '12121', '11685c71-3576-4c3c-bc94-a9d4c7132122', 'yy', '4416f3dc-bb71-49d8-9c52-ca9d4f2c9c8f', '【勿删】test-club', '12', '天津市', '1201', '市辖区', '120102', '河东区', null, null, '120102002', '大直沽街道', '1', '2018-08-01 22:50:03', '2018-08-01 22:50:03', '1');
INSERT INTO `school` VALUES ('13', '499af160-f40c-4e75-bbdd-fe3c0894fc77', '学校一', '11685c71-3576-4c3c-bc94-a9d4c7132122', 'yy', '4416f3dc-bb71-49d8-9c52-ca9d4f2c9c8f', '【勿删】test-club', '12', '天津市', '1201', '市辖区', '120102', '河东区', null, null, '120102001', '大王庄街道', '1', '2018-08-01 22:51:20', '2018-08-01 22:51:20', '1');
INSERT INTO `school` VALUES ('14', '905693e4-d203-41ee-a0d5-d8eae65fe822', '1212121', '11685c71-3576-4c3c-bc94-a9d4c7132122', 'yy', '4416f3dc-bb71-49d8-9c52-ca9d4f2c9c8f', '【勿删】test-club', '12', '天津市', '1201', '市辖区', '120102', '河东区', null, null, '120102003', '中山门街道', '1', '2018-08-01 22:56:41', '2018-08-01 22:56:41', '1');
INSERT INTO `school` VALUES ('15', 'bff5daf4-8742-43d9-9a1c-d76602246a37', '学校二', '11685c71-3576-4c3c-bc94-a9d4c7132122', '11112222222', '4416f3dc-bb71-49d8-9c52-ca9d4f2c9c8f', '【勿删】test-club', '11', '北京市', '1101', '市辖区', '110101', '东城区', null, null, '110101001', '东华门街道办事处', '1', '2018-08-01 23:35:42', '2018-08-01 23:35:42', '1');
INSERT INTO `school` VALUES ('16', '97303808-ea8e-40c9-871d-1dee9ec3855a', '皇马小学', '11685c71-3576-4c3c-bc94-a9d4c7132122', '俱乐部一', '4416f3dc-bb71-49d8-9c52-ca9d4f2c9c8f', '【勿删】test-club', '11', '北京市', '1101', '市辖区', '110101', '东城区', null, null, '110101001', '东华门街道办事处', '1', '2018-08-02 22:41:34', '2018-08-02 22:41:34', '0');
INSERT INTO `school` VALUES ('17', '9a932d7d-1826-42b8-b9b2-abd969a11f49', '学校二--11', '11685c71-3576-4c3c-bc94-a9d4c7132122', '俱乐部一', '4416f3dc-bb71-49d8-9c52-ca9d4f2c9c8f', '【勿删】test-club', '11', '北京市', '1101', '市辖区', '110105', '朝阳区', null, null, '110105002', '朝外街道办事处', '1', '2018-08-02 23:14:40', '2018-08-02 23:14:40', '1');
INSERT INTO `school` VALUES ('18', '570000c4-2e78-4525-be1b-3628027636ca', '皇马中学', '11685c71-3576-4c3c-bc94-a9d4c7132122', '俱乐部一', '4416f3dc-bb71-49d8-9c52-ca9d4f2c9c8f', '【勿删】test-club', '12', '天津市', '1201', '市辖区', '120101', '和平区', null, null, '120101001', '劝业场街道', '1', '2018-08-03 09:25:56', '2018-08-03 09:25:56', '0');
INSERT INTO `school` VALUES ('19', '0b2cfe32-60fe-482c-baa0-73b924806224', '11', '11685c71-3576-4c3c-bc94-a9d4c7132122', '俱乐部一', '4416f3dc-bb71-49d8-9c52-ca9d4f2c9c8f', '【勿删】test-club', '11', '北京市', '1101', '市辖区', '110101', '东城区', null, null, '110101002', '景山街道办事处', '1', '2018-08-03 20:19:47', '2018-08-03 20:19:47', '1');
INSERT INTO `school` VALUES ('20', 'd9d7d521-76aa-4ccb-b154-265faba19f1d', '三高', 'string', 'string', 'b42d88a1-6ad1-4831-8ecf-56d004c166d3', '杜逸斌', '11', '北京市', '1101', '市辖区', '110101', '东城区', null, null, '110101001', '东华门街道办事处', '1', '2018-08-05 16:37:51', '2018-08-05 16:37:51', '0');
INSERT INTO `school` VALUES ('21', '465327d9-59c4-4a25-acf1-a56599ca2a8d', 'xxxxx', 'bb9db48c-4262-4fe8-803e-cd7cde35f606', '俱乐部一', '61b354ff-02ea-4d98-8159-4dc61958defc', 'ao', '11', '北京市', '1101', '市辖区', '110101', '东城区', null, null, '110101001', '东华门街道办事处', '1', '2018-08-07 09:43:39', '2018-08-07 09:43:39', '0');
INSERT INTO `school` VALUES ('22', '2c0ed50e-a628-445e-92e8-84b726b4783c', 'xx', 'club-1', 'club-1', '61b354ff-02ea-4d98-8159-4dc61958defc', 'ao', '11', '北京市', '1101', '市辖区', '110101', '东城区', null, null, '110101001', '东华门街道办事处', '1', '2018-08-07 09:55:29', '2018-08-07 09:55:29', '1');
INSERT INTO `school` VALUES ('23', '12eedc3c-e4f7-4489-99d5-2c4ab93f4a58', '12121212', '11685c71-3576-4c3c-bc94-a9d4c7132122', '【勿删】皇马俱乐部', '4416f3dc-bb71-49d8-9c52-ca9d4f2c9c8f', '【勿删】test-club', '11', '北京市', '1101', '市辖区', '110101', '东城区', null, null, '110101001', '东华门街道办事处', '1', '2018-08-07 16:33:32', '2018-08-07 16:33:32', '0');
INSERT INTO `school` VALUES ('24', 'a5b53b4f-d69b-487c-b5f1-23f81204941b', '测试学校', '79eb5d6c-ed31-40dd-8131-8d4128309cc5', '测试俱乐部', '61b354ff-02ea-4d98-8159-4dc61958defc', 'ao', '11', '北京市', '1101', '市辖区', '110101', '东城区', null, null, '110101001', '东华门街道办事处', '1', '2018-08-07 17:38:53', '2018-08-07 17:38:53', '0');

-- ----------------------------
-- Table structure for `sys_role`
-- ----------------------------
DROP TABLE IF EXISTS `sys_role`;
CREATE TABLE `sys_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `description` text,
  `order_number` int(11) DEFAULT NULL,
  `delete_status` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_id` (`role_id`),
  UNIQUE KEY `code` (`code`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of sys_role
-- ----------------------------
INSERT INTO `sys_role` VALUES ('1', '10001', '管理员', 'sys_role_admin', '1', null, '10', '0');
INSERT INTO `sys_role` VALUES ('2', '10002', '俱乐部', 'sys_role_club', '1', null, '20', '0');
INSERT INTO `sys_role` VALUES ('3', '10003', '学校', 'sys_role_school', '1', null, '30', '0');
INSERT INTO `sys_role` VALUES ('4', '10004', '球队', 'sys_role_team', '1', null, '40', '0');

-- ----------------------------
-- Table structure for `sys_user_role`
-- ----------------------------
DROP TABLE IF EXISTS `sys_user_role`;
CREATE TABLE `sys_user_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` varchar(255) DEFAULT NULL,
  `role_id` varchar(255) DEFAULT NULL,
  `delete_status` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `user_id` (`uid`),
  KEY `role_id` (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of sys_user_role
-- ----------------------------
INSERT INTO `sys_user_role` VALUES ('1', '10001', '10001', '0');
INSERT INTO `sys_user_role` VALUES ('2', '10002', '10002', '1');
INSERT INTO `sys_user_role` VALUES ('3', '10003', '10003', '1');
INSERT INTO `sys_user_role` VALUES ('4', '10004', '10004', '0');
INSERT INTO `sys_user_role` VALUES ('5', '61b354ff-02ea-4d98-8159-4dc61958defc', '10001', '0');
INSERT INTO `sys_user_role` VALUES ('6', '10003', '10004', '1');
INSERT INTO `sys_user_role` VALUES ('7', '10003', '10003', '1');
INSERT INTO `sys_user_role` VALUES ('8', '10002', '10004', '0');
INSERT INTO `sys_user_role` VALUES ('9', '10003', '10004', '0');
INSERT INTO `sys_user_role` VALUES ('10', 'c5f7522f-fbbd-4b1c-b473-ead48c9baf34', '10002', '1');
INSERT INTO `sys_user_role` VALUES ('11', 'a101f16b-3847-4a12-97d5-150d5cc64e7d', '10003', '0');
INSERT INTO `sys_user_role` VALUES ('12', 'c5f7522f-fbbd-4b1c-b473-ead48c9baf34', '10003', '1');
INSERT INTO `sys_user_role` VALUES ('13', 'c5f7522f-fbbd-4b1c-b473-ead48c9baf34', '10004', '0');
INSERT INTO `sys_user_role` VALUES ('14', 'fe791cb4-a2fb-4826-8b8d-0e4e7337603a', '10001', '0');
INSERT INTO `sys_user_role` VALUES ('15', 'eb3e034d-372d-4841-a8d3-83a63fc21880', '10001', '0');
INSERT INTO `sys_user_role` VALUES ('16', '4416f3dc-bb71-49d8-9c52-ca9d4f2c9c8f', '10002', '0');
INSERT INTO `sys_user_role` VALUES ('17', 'f0adaf7d-6e64-4c61-90a9-674414fdaed7', '10001', '0');
INSERT INTO `sys_user_role` VALUES ('18', 'b42d88a1-6ad1-4831-8ecf-56d004c166d3', '10001', '0');
INSERT INTO `sys_user_role` VALUES ('19', '7afbaddd-4b9e-4794-abfd-6a0a191a53fd', '10002', '1');
INSERT INTO `sys_user_role` VALUES ('20', '82d82ad1-463f-4760-999d-104e78114f42', '10001', '0');
INSERT INTO `sys_user_role` VALUES ('21', '7afbaddd-4b9e-4794-abfd-6a0a191a53fd', '10003', '0');
INSERT INTO `sys_user_role` VALUES ('22', '3fec4ec6-2636-4c4e-a483-348ddd084246', '10004', '0');
INSERT INTO `sys_user_role` VALUES ('23', '47fbf3b1-861a-40fc-826b-d506b17bf7b8', '10003', '1');
INSERT INTO `sys_user_role` VALUES ('24', '972825f6-e672-4ff7-abce-60fef8a818af', '10003', '0');
INSERT INTO `sys_user_role` VALUES ('25', '47fbf3b1-861a-40fc-826b-d506b17bf7b8', '10004', '0');
INSERT INTO `sys_user_role` VALUES ('26', 'c42ed1c3-2d6a-44ef-92c1-a0f9fbf97cfd', '10003', '0');
INSERT INTO `sys_user_role` VALUES ('27', '240e77d7-8329-459b-8497-1fead433bb52', '10002', '0');
INSERT INTO `sys_user_role` VALUES ('28', 'b8d296bd-01a1-4695-8dfa-db48cfd3a825', '10002', '0');
INSERT INTO `sys_user_role` VALUES ('29', 'a43071b7-cb70-4d5a-8bc7-ed31f23e716f', '10002', '0');
INSERT INTO `sys_user_role` VALUES ('30', 'f07b747c-89f3-4426-b571-e3305073a656', '10003', '0');
INSERT INTO `sys_user_role` VALUES ('31', 'f5b7bcdb-3d7e-4466-8b95-82548cd86119', '10003', '0');
INSERT INTO `sys_user_role` VALUES ('32', '68d9e5b8-854a-481e-a0e4-aaf3a98d3749', '10002', '0');

-- ----------------------------
-- Table structure for `team`
-- ----------------------------
DROP TABLE IF EXISTS `team`;
CREATE TABLE `team` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `team_id` varchar(255) NOT NULL,
  `team_name` varchar(255) DEFAULT NULL,
  `school_id` varchar(255) NOT NULL,
  `school_name` varchar(255) DEFAULT NULL,
  `admin_id` varchar(255) DEFAULT NULL COMMENT '管理员uid',
  `admin_name` varchar(255) DEFAULT NULL COMMENT '管理员姓名',
  `province` varchar(255) DEFAULT NULL COMMENT '省',
  `province_name` varchar(255) DEFAULT NULL COMMENT '省',
  `city` varchar(255) DEFAULT NULL COMMENT '市',
  `city_name` varchar(255) DEFAULT NULL COMMENT '市',
  `region` varchar(255) DEFAULT NULL COMMENT '区',
  `region_name` varchar(255) DEFAULT NULL COMMENT '区',
  `county` varchar(255) DEFAULT NULL COMMENT '县',
  `county_name` varchar(255) DEFAULT NULL COMMENT '县',
  `street` varchar(255) DEFAULT NULL COMMENT '街道',
  `street_name` varchar(255) DEFAULT NULL COMMENT '街道',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '0：无效用户 1：有效, -1 预分配uid用户',
  `create_time` datetime DEFAULT NULL,
  `active_time` datetime DEFAULT NULL COMMENT '激活时间',
  `delete_status` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `team_id` (`team_id`) USING BTREE,
  KEY `school_id` (`school_id`) USING BTREE,
  KEY `admin_id` (`admin_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of team
-- ----------------------------
INSERT INTO `team` VALUES ('1', 'team-1', 'team-11', 'school-1', 'school-1', '10001', 'a', null, null, null, null, null, null, null, null, null, null, '1', '2018-07-23 13:07:15', '2018-07-23 13:07:15', '0');
INSERT INTO `team` VALUES ('2', 'e5d4ecfc-b589-40d9-8e15-fdbea844851c', '1212', '6b3417d2-9e85-463a-828a-77a445d13647', '3131', '4416f3dc-bb71-49d8-9c52-ca9d4f2c9c8f', 'test', '12', '天津市', '1201', '市辖区', '120102', '河东区', null, null, '120102003', '中山门街道', '1', '2018-07-30 22:34:38', '2018-07-30 22:34:38', '0');
INSERT INTO `team` VALUES ('3', '19cf1ede-910e-4781-b948-b8c7148a0997', 'dadada', 'eaa2af36-d57d-46a1-9a6c-0350ae80815d', '1dadad', '4416f3dc-bb71-49d8-9c52-ca9d4f2c9c8f', 'test', '14', '山西省', '1404', '长治市', '140423', '襄垣县', null, null, '140423103', '夏店镇', '1', '2018-07-30 22:55:09', '2018-07-30 22:55:09', '0');
INSERT INTO `team` VALUES ('4', '78f3cb0f-2d14-4321-90f7-522411063951', '队伍一', '8424fc2c-665c-418d-b348-900545039c1f', '学校测试1', '4416f3dc-bb71-49d8-9c52-ca9d4f2c9c8f', 'test', '12', '天津市', '1201', '市辖区', '120102', '河东区', null, null, '120102001', '大王庄街道', '1', '2018-07-30 22:58:40', '2018-07-30 22:58:40', '0');
INSERT INTO `team` VALUES ('5', '4d1f909c-129d-4ae6-96cb-3a6a79a03624', '测试队伍11', '97303808-ea8e-40c9-871d-1dee9ec3855a', '学校一', '4416f3dc-bb71-49d8-9c52-ca9d4f2c9c8f', '【勿删】test-club', '12', '天津市', '1201', '市辖区', '120102', '河东区', null, null, '120102001', '大王庄街道', '1', '2018-08-02 23:34:33', '2018-08-02 23:34:33', '1');
INSERT INTO `team` VALUES ('6', 'c0350de5-eb25-48d8-8d71-a84c6768ed90', '队伍一', '97303808-ea8e-40c9-871d-1dee9ec3855a', '学校一', '4416f3dc-bb71-49d8-9c52-ca9d4f2c9c8f', '【勿删】test-club', '12', '天津市', '1201', '市辖区', '120101', '和平区', null, null, '120101001', '劝业场街道', '1', '2018-08-02 23:38:58', '2018-08-02 23:38:58', '1');
INSERT INTO `team` VALUES ('7', 'e7f3614d-daa4-407d-b1b4-0cc105ba2fb6', 'U8', '97303808-ea8e-40c9-871d-1dee9ec3855a', '学校一', '4416f3dc-bb71-49d8-9c52-ca9d4f2c9c8f', '【勿删】test-club', '12', '天津市', '1201', '市辖区', '120101', '和平区', null, null, '120101001', '劝业场街道', '1', '2018-08-02 23:40:07', '2018-08-02 23:40:07', '1');
INSERT INTO `team` VALUES ('8', 'ce6a8737-486d-4a34-840a-1beaf0f34128', 'U7', '97303808-ea8e-40c9-871d-1dee9ec3855a', '学校一', '4416f3dc-bb71-49d8-9c52-ca9d4f2c9c8f', '【勿删】test-club', '11', '北京市', '1101', '市辖区', '110101', '东城区', null, null, '110101002', '景山街道办事处', '1', '2018-08-03 09:19:11', '2018-08-03 09:19:11', '0');
INSERT INTO `team` VALUES ('9', 'd4630b7a-9e7c-4093-a93f-04f0e5256d01', 'U7', '570000c4-2e78-4525-be1b-3628027636ca', '学校二', '4416f3dc-bb71-49d8-9c52-ca9d4f2c9c8f', '【勿删】test-club', '13', '河北省', '1302', '唐山市', '130203', '路北区', null, null, '130203002', '文化路街道办事处', '1', '2018-08-03 10:45:41', '2018-08-03 10:45:41', '0');
INSERT INTO `team` VALUES ('10', '6d3e9ae6-5f64-45bf-b149-1d186cd74bc8', '辉煌国际小学队1', 'babf588f-8da3-40d6-82ca-e5be37de8ffb', '辉煌国际', '7afbaddd-4b9e-4794-abfd-6a0a191a53fd', '刘总1', '11', '北京市', '1101', '市辖区', '110107', '石景山区', null, null, '110107001', '八宝山街道办事处', '1', '2018-08-05 10:05:57', '2018-08-05 10:05:57', '0');
INSERT INTO `team` VALUES ('11', '8fa66d1c-2a61-4783-b547-0258545f0361', '11222', 'babf588f-8da3-40d6-82ca-e5be37de8ffb', '辉煌国际', '7afbaddd-4b9e-4794-abfd-6a0a191a53fd', '刘总1', '11', '北京市', '1101', '市辖区', '110102', '西城区', null, null, '110102001', '西长安街街道办事处', '1', '2018-08-07 10:51:18', '2018-08-07 10:51:18', '1');
INSERT INTO `team` VALUES ('12', '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', '11', '07f4a2ae-8c70-4225-8ac8-739554ab6cbc', '1212', '10002', 'A', '11', '北京市', '1101', '市辖区', '110101', '东城区', null, null, '110101001', '东华门街道办事处', '1', '2018-08-07 10:52:06', '2018-08-07 10:52:06', '0');
INSERT INTO `team` VALUES ('13', '525abf05-05af-41b0-a257-85572027d54a', '33', '07f4a2ae-8c70-4225-8ac8-739554ab6cbc', '1212', '10002', 'A', '11', '北京市', '1101', '市辖区', '110101', '东城区', null, null, '110101001', '东华门街道办事处', '1', '2018-08-07 10:54:02', '2018-08-07 10:54:02', '1');
INSERT INTO `team` VALUES ('14', '72b47f6a-6400-485c-9d65-601606e72943', 'U8', '97303808-ea8e-40c9-871d-1dee9ec3855a', '皇马小学', '4416f3dc-bb71-49d8-9c52-ca9d4f2c9c8f', '【勿删】test-club', '11', '北京市', '1101', '市辖区', '110101', '东城区', null, null, '110101001', '东华门街道办事处', '1', '2018-08-07 16:45:18', '2018-08-07 16:45:18', '0');
INSERT INTO `team` VALUES ('15', 'a5750cc3-fde6-40f9-8710-da5d83ac9cde', 'U9', '97303808-ea8e-40c9-871d-1dee9ec3855a', '皇马小学', '4416f3dc-bb71-49d8-9c52-ca9d4f2c9c8f', '【勿删】test-club', '12', '天津市', '1201', '市辖区', '120102', '河东区', null, null, '120102001', '大王庄街道', '1', '2018-08-07 16:46:39', '2018-08-07 16:46:39', '0');
INSERT INTO `team` VALUES ('16', '66a6ddcb-2be3-493e-aad2-c32280d9e5e1', '11', '12eedc3c-e4f7-4489-99d5-2c4ab93f4a58', '12121212', '4416f3dc-bb71-49d8-9c52-ca9d4f2c9c8f', '【勿删】test-club', '11', '北京市', '1101', '市辖区', '110101', '东城区', null, null, '110101001', '东华门街道办事处', '1', '2018-08-07 16:51:10', '2018-08-07 16:51:10', '0');
INSERT INTO `team` VALUES ('17', 'ac5e652f-1a38-4890-bb67-0df5d7aaa816', '测试队伍', 'a5b53b4f-d69b-487c-b5f1-23f81204941b', '测试学校', '61b354ff-02ea-4d98-8159-4dc61958defc', 'ao', '11', '北京市', '1101', '市辖区', '110101', '东城区', null, null, '110101001', '东华门街道办事处', '1', '2018-08-07 17:39:11', '2018-08-07 17:39:11', '0');

-- ----------------------------
-- Table structure for `team_coach`
-- ----------------------------
DROP TABLE IF EXISTS `team_coach`;
CREATE TABLE `team_coach` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `coach_id` varchar(255) DEFAULT NULL COMMENT '队员id',
  `name` varchar(255) DEFAULT NULL COMMENT '姓名',
  `id_number` varchar(255) DEFAULT NULL COMMENT '身份证号',
  `phone` varchar(20) DEFAULT NULL COMMENT '手机号',
  `age` tinyint(4) DEFAULT NULL COMMENT '年龄',
  `photo` varchar(255) DEFAULT NULL COMMENT '照片',
  `team_id` varchar(255) NOT NULL,
  `team_name` varchar(255) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `delete_status` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `coach_id` (`coach_id`) USING BTREE,
  KEY `team_id` (`team_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of team_coach
-- ----------------------------
INSERT INTO `team_coach` VALUES ('2', 'coach-1', 'coach-1', 'string', null, '25', 'xxxx', 'team-1', 'team-1', '2018-07-27 18:31:59', '0');
INSERT INTO `team_coach` VALUES ('3', 'coach-2', 'coach-2', '123546789', null, '15', 'xxx', 'team-1', 'teaam-1', '2018-07-23 13:10:21', '0');
INSERT INTO `team_coach` VALUES ('4', 'a589fa54-9a24-4be8-b92d-26dfccb2f9aa', '11', null, null, null, null, 'e7f3614d-daa4-407d-b1b4-0cc105ba2fb6', '队伍二', '2018-08-03 10:43:54', '0');
INSERT INTO `team_coach` VALUES ('5', 'd9b2b7f2-b7a1-4455-8fa2-ae513044aace', '1', null, null, null, null, 'd4630b7a-9e7c-4093-a93f-04f0e5256d01', 'U7', '2018-08-03 10:46:03', '0');
INSERT INTO `team_coach` VALUES ('6', '70b5fcf7-1c46-46b0-ab76-9b6c6b40449d', '王教练', null, null, null, null, 'ce6a8737-486d-4a34-840a-1beaf0f34128', 'U7', '2018-08-04 12:28:38', '0');
INSERT INTO `team_coach` VALUES ('7', 'e5b0e808-2fd8-451a-9754-321f32954953', '11', null, null, null, null, '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', '11', '2018-08-07 10:53:30', '1');
INSERT INTO `team_coach` VALUES ('8', '43af48cb-28da-461c-b841-9859dec3dc82', '22', null, null, null, null, '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', '11', '2018-08-07 11:09:02', '1');
INSERT INTO `team_coach` VALUES ('9', '50e489c8-d8e8-4356-ab46-acb7c495ea06', '33', null, null, null, null, '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', '11', '2018-08-07 11:11:19', '1');
INSERT INTO `team_coach` VALUES ('10', 'd261fb32-a4c5-4aaf-85d9-c99e13c545ea', 'xxx', null, null, null, null, '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', '11', '2018-08-07 11:48:55', '1');
INSERT INTO `team_coach` VALUES ('11', '33b2ec63-7ed6-468f-b9b1-bb858768c487', '11', null, null, null, null, '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', '11', '2018-08-07 12:03:44', '0');

-- ----------------------------
-- Table structure for `team_member`
-- ----------------------------
DROP TABLE IF EXISTS `team_member`;
CREATE TABLE `team_member` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `member_id` varchar(255) DEFAULT NULL COMMENT '队员id',
  `number` varchar(255) DEFAULT NULL COMMENT '球衣号',
  `name` varchar(255) DEFAULT NULL COMMENT '姓名',
  `id_number` varchar(255) DEFAULT NULL COMMENT '身份证号',
  `age` tinyint(4) DEFAULT NULL COMMENT '年龄',
  `height` decimal(5,2) DEFAULT NULL COMMENT '身高',
  `weight` decimal(5,2) DEFAULT NULL COMMENT '体重',
  `photo` varchar(255) DEFAULT NULL COMMENT '照片',
  `first_position` varchar(255) DEFAULT NULL COMMENT '第一位置',
  `second_position` varchar(255) DEFAULT NULL COMMENT '第二位置',
  `attack` decimal(8,4) DEFAULT NULL COMMENT '进攻评分',
  `speed` decimal(8,4) DEFAULT NULL COMMENT '速度评分',
  `technology` decimal(8,4) DEFAULT NULL COMMENT '技术评分',
  `defense` decimal(8,4) DEFAULT NULL COMMENT '防守评分',
  `team` decimal(8,4) DEFAULT NULL COMMENT '团队评分',
  `endurance` decimal(8,4) DEFAULT NULL COMMENT '耐力评分',
  `team_id` varchar(255) NOT NULL,
  `team_name` varchar(255) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `delete_status` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `member_id` (`member_id`) USING BTREE,
  KEY `team_id` (`team_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of team_member
-- ----------------------------
INSERT INTO `team_member` VALUES ('1', 'member-1', '1', '张三', '123546789', '15', '154.00', '51.20', 'xxx', '中锋', '前锋', null, null, null, null, null, null, 'team-1', 'teaam-1', '2018-07-23 13:10:21', '0');
INSERT INTO `team_member` VALUES ('2', '70dc7f97-0f48-473a-b925-9a8176d96a49', '2', '李四', '123546789', '15', '154.00', '51.20', null, '中锋', '前锋', null, null, null, null, null, null, 'team-1', 'team-11', '2018-07-30 09:53:42', '0');
INSERT INTO `team_member` VALUES ('3', '8843933c-5948-484c-b13d-01434cc27e53', '5', '王五', '123546789', '15', '154.00', '51.20', null, '中锋', '后卫', null, null, null, null, null, null, 'team-1', 'team-11', '2018-07-30 09:53:42', '0');
INSERT INTO `team_member` VALUES ('4', '3d71aaf5-cd6b-4c26-9790-d64f0278adb9', '2', '李四', '123546789', '15', '154.00', '51.20', 'xxx', '中锋', '前锋', '2.0000', '3.0000', '4.0000', '5.0000', '5.0000', '4.0000', 'team-1', 'team-11', '2018-07-30 09:58:14', '0');
INSERT INTO `team_member` VALUES ('5', '808ec1ce-2907-4af9-81ae-4d4a2c07e21a', '5', '王五', '123546789', '15', '154.00', '51.20', null, '中锋', '后卫', null, null, null, null, null, null, 'team-1', 'team-11', '2018-07-30 09:58:14', '0');
INSERT INTO `team_member` VALUES ('6', '0974d668-78b6-45a1-9817-953b8938919a', '1', '1', '1234121212121234', '1', '1.00', '1.00', 'http://207.148.82.48:5556/images/2018-08-03/165106-4a8d6375-4718-4844-85a9-6d96701dbdac.jpg', 'goalkeeper', 'frontal', null, null, null, null, null, null, 'e7f3614d-daa4-407d-b1b4-0cc105ba2fb6', '队伍二', '2018-08-03 10:41:08', '0');
INSERT INTO `team_member` VALUES ('7', 'e5ce58da-33f3-485e-add2-deb0a703a1b1', '2', '2', '2222111112121212', '1', '1.00', '1.00', null, 'goalkeeper', 'frontal', null, null, null, null, null, null, 'e7f3614d-daa4-407d-b1b4-0cc105ba2fb6', '队伍二', '2018-08-03 10:43:38', '1');
INSERT INTO `team_member` VALUES ('8', '32ccefc9-10cc-463c-8120-e6ec903506fc', '1', '1', '1234123412121234', '1', '1.00', '1.00', null, 'goalkeeper', 'frontal', null, null, null, null, null, null, 'd4630b7a-9e7c-4093-a93f-04f0e5256d01', 'U7', '2018-08-03 10:45:53', '0');
INSERT INTO `team_member` VALUES ('9', '2861a582-6233-48d3-a979-a4b964ec6d94', '1', '1', '1234123412121234', '1', '1.00', '1.00', 'http://207.148.82.48:5556/images/2018-08-03/104758-bdf17665-6cb1-4a33-ba03-5c44af9865ff.jpg', 'goalkeeper', 'frontal', null, null, null, null, null, null, 'd4630b7a-9e7c-4093-a93f-04f0e5256d01', 'U7', '2018-08-03 10:48:00', '0');
INSERT INTO `team_member` VALUES ('10', '31b9f3ce-a65c-496e-aa40-d96519013175', '2', '李四', '123546789', '15', '154.00', '51.20', null, '中锋', '前锋', null, null, null, null, null, null, 'e7f3614d-daa4-407d-b1b4-0cc105ba2fb6', '队伍二', '2018-08-03 15:30:02', '1');
INSERT INTO `team_member` VALUES ('11', '15dac038-d3e3-40cd-8bb0-6b37e2734ed6', '5', '王五', '123546789', '15', '154.00', '51.20', null, '中锋', '后卫', null, null, null, null, null, null, 'e7f3614d-daa4-407d-b1b4-0cc105ba2fb6', '队伍二', '2018-08-03 15:30:02', '1');
INSERT INTO `team_member` VALUES ('12', 'c9e0adb4-65d8-462c-83ed-9ce7041f2de1', '1', '1', '1234123412121234', '1', '1.00', '1.00', null, 'goalkeeper', 'frontal', null, null, null, null, null, null, 'e7f3614d-daa4-407d-b1b4-0cc105ba2fb6', '队伍二', '2018-08-03 16:59:36', '0');
INSERT INTO `team_member` VALUES ('13', '083d5ed4-1ffb-4c17-944a-f44d2b4b3608', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, 'e7f3614d-daa4-407d-b1b4-0cc105ba2fb6', 'U8', '2018-08-04 11:21:21', '0');
INSERT INTO `team_member` VALUES ('14', '55f9bf51-276c-4ef9-a835-6dc8fe71b5e0', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, 'e7f3614d-daa4-407d-b1b4-0cc105ba2fb6', 'U8', '2018-08-04 11:21:21', '0');
INSERT INTO `team_member` VALUES ('15', '8b546673-54a7-4f55-91de-cf6fb95b71ed', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, 'e7f3614d-daa4-407d-b1b4-0cc105ba2fb6', 'U8', '2018-08-04 11:21:21', '0');
INSERT INTO `team_member` VALUES ('16', 'a340e1d9-3c88-4cf5-b731-43a810ef6b9a', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, 'e7f3614d-daa4-407d-b1b4-0cc105ba2fb6', 'U8', '2018-08-04 11:21:21', '0');
INSERT INTO `team_member` VALUES ('17', '2d9612b8-2619-4693-9e2e-645bca0c8ed7', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, 'e7f3614d-daa4-407d-b1b4-0cc105ba2fb6', 'U8', '2018-08-04 11:21:21', '0');
INSERT INTO `team_member` VALUES ('18', '358f8273-5293-4ed4-9726-f9027c5449ee', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, 'e7f3614d-daa4-407d-b1b4-0cc105ba2fb6', 'U8', '2018-08-04 11:21:21', '0');
INSERT INTO `team_member` VALUES ('19', 'cb4a5d28-5d23-474c-8968-b598f4686396', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, 'e7f3614d-daa4-407d-b1b4-0cc105ba2fb6', 'U8', '2018-08-04 11:21:21', '0');
INSERT INTO `team_member` VALUES ('20', 'a98588ef-9d06-45c3-99e0-c14cc85ed37d', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, 'e7f3614d-daa4-407d-b1b4-0cc105ba2fb6', 'U8', '2018-08-04 11:21:21', '0');
INSERT INTO `team_member` VALUES ('21', 'a7860c08-7373-4cf6-96a9-a2a59a28889b', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, 'e7f3614d-daa4-407d-b1b4-0cc105ba2fb6', 'U8', '2018-08-04 11:21:21', '0');
INSERT INTO `team_member` VALUES ('22', '542b0950-676d-4a6d-ac3c-02fd71b0801e', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, 'e7f3614d-daa4-407d-b1b4-0cc105ba2fb6', 'U8', '2018-08-04 11:21:21', '0');
INSERT INTO `team_member` VALUES ('23', 'fb3996f4-bd27-47a7-8f59-0cd27389771a', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, 'e7f3614d-daa4-407d-b1b4-0cc105ba2fb6', 'U8', '2018-08-04 11:21:21', '0');
INSERT INTO `team_member` VALUES ('24', '4e7f1e72-6399-4380-bfc2-11db07d294b3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, 'e7f3614d-daa4-407d-b1b4-0cc105ba2fb6', 'U8', '2018-08-04 11:21:21', '0');
INSERT INTO `team_member` VALUES ('25', 'a36af897-479e-472f-8138-72a4ecaf0d64', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, 'e7f3614d-daa4-407d-b1b4-0cc105ba2fb6', 'U8', '2018-08-04 11:21:21', '0');
INSERT INTO `team_member` VALUES ('26', 'fc525dc2-edba-4018-ac4e-aae87b284b08', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, 'e7f3614d-daa4-407d-b1b4-0cc105ba2fb6', 'U8', '2018-08-04 11:21:21', '0');
INSERT INTO `team_member` VALUES ('27', '4a9dedae-5fd3-4963-b14b-a0923fecb3f2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, 'e7f3614d-daa4-407d-b1b4-0cc105ba2fb6', 'U8', '2018-08-04 11:21:21', '0');
INSERT INTO `team_member` VALUES ('28', '05258d20-4025-4f53-8f3b-631ad9fdc755', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, 'e7f3614d-daa4-407d-b1b4-0cc105ba2fb6', 'U8', '2018-08-04 11:21:21', '0');
INSERT INTO `team_member` VALUES ('29', 'e8d787c8-f1d0-45a6-ba7e-92287236727c', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, 'e7f3614d-daa4-407d-b1b4-0cc105ba2fb6', 'U8', '2018-08-04 11:21:21', '0');
INSERT INTO `team_member` VALUES ('30', '6c7f38f3-4db7-4252-907a-721c96a98803', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, 'e7f3614d-daa4-407d-b1b4-0cc105ba2fb6', 'U8', '2018-08-04 11:21:21', '0');
INSERT INTO `team_member` VALUES ('31', 'ae5eb3af-110f-40f4-b925-2e0e18dc1006', '1', '陈柏宇', '100111201203011000', '9', '146.00', '35.00', 'http://207.148.82.48:5556/images/2018-08-04/112828-1975de93-537f-4543-8f8f-3404afa50319.png', '守门员', '边后卫', null, null, null, null, null, null, 'ce6a8737-486d-4a34-840a-1beaf0f34128', 'U7', '2018-08-04 11:24:26', '0');
INSERT INTO `team_member` VALUES ('32', 'bdb3ef1f-1595-41f2-82c1-2f1cda390730', '2', '柳烨阳', '100111201203011000', '9', '130.00', '25.00', 'http://207.148.82.48:5556/images/2018-08-04/113129-fabb22e6-831a-4465-99ff-47563b3ebeff.png', '右边前卫', '左边前卫', null, null, null, null, null, null, 'ce6a8737-486d-4a34-840a-1beaf0f34128', 'U7', '2018-08-04 11:24:26', '0');
INSERT INTO `team_member` VALUES ('33', '6dd6d913-2b67-4505-a30d-c2f050e872ef', '3', '杜禹铭', '100111201203011000', '8', '140.00', '40.00', 'http://207.148.82.48:5556/images/2018-08-04/113243-f84433b2-2093-4f17-884c-344df1bca79f.png', '中后卫', '前锋', null, null, null, null, null, null, 'ce6a8737-486d-4a34-840a-1beaf0f34128', 'U7', '2018-08-04 11:24:26', '0');
INSERT INTO `team_member` VALUES ('34', '58105e48-960b-4e50-bb28-5d4b306e07a1', '4', '黄山', '100111201203011000', '8', '135.00', '25.00', 'http://207.148.82.48:5556/images/2018-08-04/113257-ff1d2536-08cd-4d86-9668-188ad0d81373.png', '守门员', '后腰', null, null, null, null, null, null, 'ce6a8737-486d-4a34-840a-1beaf0f34128', 'U7', '2018-08-04 11:24:26', '0');
INSERT INTO `team_member` VALUES ('35', 'c1f2b613-5a34-49ba-93af-0aceaf3171c3', '5', '张峻诚', '100111201203011000', '9', '140.00', '30.00', 'http://207.148.82.48:5556/images/2018-08-04/113311-9402f15d-94f3-4e85-b04a-b26b5709b9f5.png', '中后卫', '前腰', null, null, null, null, null, null, 'ce6a8737-486d-4a34-840a-1beaf0f34128', 'U7', '2018-08-04 11:24:26', '0');
INSERT INTO `team_member` VALUES ('36', '5d3141c6-584b-4b21-b6c6-768c3eb2c70e', '6', '陈九木', '100111201203011000', '9', '142.00', '36.00', 'http://207.148.82.48:5556/images/2018-08-04/113323-52ce1455-d93f-4ca7-8208-096aaafa8d57.png', '前锋', '边锋', null, null, null, null, null, null, 'ce6a8737-486d-4a34-840a-1beaf0f34128', 'U7', '2018-08-04 11:24:26', '0');
INSERT INTO `team_member` VALUES ('37', '8b4dc197-4d07-4347-a83a-f37685c3942a', '7', '李梓腾', '100111201203011000', '9', '135.00', '35.00', 'http://207.148.82.48:5556/images/2018-08-04/113343-75c84916-39b8-4635-ab1b-052061313f0f.png', '右边前卫', '边后卫', null, null, null, null, null, null, 'ce6a8737-486d-4a34-840a-1beaf0f34128', 'U7', '2018-08-04 11:24:26', '0');
INSERT INTO `team_member` VALUES ('38', '5374adf0-a80b-4923-b9f6-44cf561950d8', '8', '曹添易', '100111201203011000', '9', '135.00', '36.00', 'http://207.148.82.48:5556/images/2018-08-04/113401-1ff61d6b-9fe6-4a2c-9626-14eb8eca71a1.png', '边锋', '边后卫', null, null, null, null, null, null, 'ce6a8737-486d-4a34-840a-1beaf0f34128', 'U7', '2018-08-04 11:24:26', '0');
INSERT INTO `team_member` VALUES ('39', '697b6676-1851-4f42-83e7-73d910351e5a', '10', '王梓瑞', '100111201203011000', '9', '135.00', '30.00', 'http://207.148.82.48:5556/images/2018-08-04/113441-c3ef1db7-33fa-47ea-8868-8b6f4a569055.png', '守门员', '边后卫', null, null, null, null, null, null, 'ce6a8737-486d-4a34-840a-1beaf0f34128', 'U7', '2018-08-04 11:24:26', '0');
INSERT INTO `team_member` VALUES ('40', '985b6372-bea9-441d-9693-4507d3b13a84', '11', '杨文轩', '100111201203011000', '9', '135.00', '30.00', null, '左边卫', '边后卫', null, null, null, null, null, null, 'ce6a8737-486d-4a34-840a-1beaf0f34128', 'U7', '2018-08-04 11:24:26', '0');
INSERT INTO `team_member` VALUES ('41', '2a89a11b-3f52-4f8d-9c25-c4b321076388', '12', '张光毅', '100111201203011000', '9', '130.00', '25.00', null, '左边卫', '边后卫', null, null, null, null, null, null, 'ce6a8737-486d-4a34-840a-1beaf0f34128', 'U7', '2018-08-04 11:24:26', '0');
INSERT INTO `team_member` VALUES ('42', '79834873-10a7-4d58-8005-8895b03595eb', '13', '曾思齐', '100111201203011000', '9', '135.00', '30.00', null, '右边卫', '边后卫', null, null, null, null, null, null, 'ce6a8737-486d-4a34-840a-1beaf0f34128', 'U7', '2018-08-04 11:24:26', '0');
INSERT INTO `team_member` VALUES ('43', '442ce994-f039-406c-b658-a4a0699bdab3', '15', '马浩轩', '100111201203011000', '9', '142.00', '40.00', null, '中后卫', '边后卫', null, null, null, null, null, null, 'ce6a8737-486d-4a34-840a-1beaf0f34128', 'U7', '2018-08-04 11:24:26', '0');
INSERT INTO `team_member` VALUES ('44', '6c5dd126-fe48-441c-9d9a-113c077fc1ce', '16', '魏文昊', '100111201203011000', '8', '130.00', '23.00', null, '左边卫', '边后卫', null, null, null, null, null, null, 'ce6a8737-486d-4a34-840a-1beaf0f34128', 'U7', '2018-08-04 11:24:26', '0');
INSERT INTO `team_member` VALUES ('45', 'e2e337a9-a16a-41cb-900a-cff573d086d5', '17', '刘宗昊', '100111201203011000', '8', '130.00', '28.00', null, '右边卫', '边后卫', null, null, null, null, null, null, 'ce6a8737-486d-4a34-840a-1beaf0f34128', 'U7', '2018-08-04 11:24:26', '0');
INSERT INTO `team_member` VALUES ('46', '5102d6e2-603e-4721-b4b1-89e204453d20', '18', '孟靖洲', '100111201203011000', '8', '125.00', '25.00', null, '前锋', '边后卫', null, null, null, null, null, null, 'ce6a8737-486d-4a34-840a-1beaf0f34128', 'U7', '2018-08-04 11:24:26', '0');
INSERT INTO `team_member` VALUES ('47', 'a1e6cf44-4475-497b-ad4e-ec44e329b026', '19', '王梓杰', '100111201203011000', '8', '135.00', '35.00', null, '守门员', '边后卫', null, null, null, null, null, null, 'ce6a8737-486d-4a34-840a-1beaf0f34128', 'U7', '2018-08-04 11:24:26', '0');
INSERT INTO `team_member` VALUES ('48', '38686644-ce18-4c2c-a33e-a36ab3ae819e', '20', '王嘉晨', '100111201203011000', '8', '126.00', '25.00', null, '前锋', '边后卫', null, null, null, null, null, null, 'ce6a8737-486d-4a34-840a-1beaf0f34128', 'U7', '2018-08-04 11:24:26', '0');
INSERT INTO `team_member` VALUES ('49', 'e614b094-f4f0-4c0f-aced-ec5973e3b434', '1', '刘浩然', '1234123412121234', '1', '1.00', '1.00', null, '守门员', '后腰', null, null, null, null, null, null, '6d3e9ae6-5f64-45bf-b149-1d186cd74bc8', '辉煌国际小学队', '2018-08-05 10:06:26', '0');
INSERT INTO `team_member` VALUES ('50', '76e16dca-a768-4e75-922b-e00b391bed44', '1', '1', '123412123412121234', '1', '1.00', '1.00', null, '守门员', '守门员', null, null, null, null, null, null, '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', '11', '2018-08-07 11:11:34', '0');
INSERT INTO `team_member` VALUES ('51', '3feb6b9a-c39b-4f9b-8638-b5866feee1ca', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', '11', '2018-08-11 09:29:59', '0');
INSERT INTO `team_member` VALUES ('52', 'e367c8ce-8e47-4070-9cd6-01b970b92c36', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', '11', '2018-08-11 09:30:00', '0');
INSERT INTO `team_member` VALUES ('53', '5b87e7fa-d5e5-4fdf-8898-12365f657f0e', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', '11', '2018-08-11 09:30:00', '0');
INSERT INTO `team_member` VALUES ('54', 'b5dc59b9-f6ce-4fc4-94c2-e8abe0854329', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', '11', '2018-08-11 09:30:00', '0');
INSERT INTO `team_member` VALUES ('55', '85a65639-ff1a-4db7-ab60-f9935f0ece0d', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', '11', '2018-08-11 09:30:00', '0');
INSERT INTO `team_member` VALUES ('56', '4c5ec02e-1b1a-4e78-818a-f88ef58b0aaf', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', '11', '2018-08-11 09:30:00', '0');
INSERT INTO `team_member` VALUES ('57', 'a58a5938-6a4a-446e-b097-069e893343c2', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', '11', '2018-08-11 09:30:00', '0');
INSERT INTO `team_member` VALUES ('58', '4b8c3d54-7133-4762-a2d5-52cd5b9b60ac', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', '11', '2018-08-11 09:30:00', '0');
INSERT INTO `team_member` VALUES ('59', '09deea5a-7a30-4af1-94cb-5af64bf61ac8', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', '11', '2018-08-11 09:30:00', '0');
INSERT INTO `team_member` VALUES ('60', '074b86ea-3e83-444f-b4c2-22d3212ee9be', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', '11', '2018-08-11 09:30:00', '0');
INSERT INTO `team_member` VALUES ('61', '8dca31a0-90d8-4cc6-b8e9-02d93c2b04e5', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', '11', '2018-08-11 09:30:00', '0');
INSERT INTO `team_member` VALUES ('62', '28bdae2c-6789-4b1e-b551-51e26e9bd9cd', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', '11', '2018-08-11 09:30:00', '0');
INSERT INTO `team_member` VALUES ('63', '0fa45b67-4a90-4dc9-bd30-2dc053555e9a', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', '11', '2018-08-11 09:30:00', '0');
INSERT INTO `team_member` VALUES ('64', '0ca21891-5bc7-4091-99aa-e399b7a23e8b', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', '11', '2018-08-11 09:30:00', '0');
INSERT INTO `team_member` VALUES ('65', '758876c7-a1df-4f60-89f0-3538ef80ac0a', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', '11', '2018-08-11 09:30:00', '0');
INSERT INTO `team_member` VALUES ('66', 'f61cad88-a886-4a0b-98ba-05e6ea396b1b', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', '11', '2018-08-11 09:30:00', '0');
INSERT INTO `team_member` VALUES ('67', '02493579-3017-457a-a46f-3fc3dcce3f0a', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', '11', '2018-08-11 09:30:00', '0');
INSERT INTO `team_member` VALUES ('68', '4be77d84-70f9-4c25-8159-aa383f632a7c', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, '6ae140d2-d18d-4091-b80c-2aa5e36a8d99', '11', '2018-08-11 09:30:00', '0');
INSERT INTO `team_member` VALUES ('69', 'ab1ef50e-bd13-4e0c-9613-c3b512e1848b', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, '66a6ddcb-2be3-493e-aad2-c32280d9e5e1', '11', '2018-08-11 09:36:11', '0');
INSERT INTO `team_member` VALUES ('70', '9de30286-5c10-47f3-a157-5b2c0c464a78', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, '66a6ddcb-2be3-493e-aad2-c32280d9e5e1', '11', '2018-08-11 09:36:11', '0');
INSERT INTO `team_member` VALUES ('71', 'd4702715-ec5a-4ca7-9b45-41189e82c631', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, '66a6ddcb-2be3-493e-aad2-c32280d9e5e1', '11', '2018-08-11 09:36:11', '0');
INSERT INTO `team_member` VALUES ('72', '37fc011c-231c-4eef-a444-41334348466a', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, '66a6ddcb-2be3-493e-aad2-c32280d9e5e1', '11', '2018-08-11 09:36:11', '0');
INSERT INTO `team_member` VALUES ('73', '9bc85c2a-7793-4072-8d7e-5488b86990d3', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, '66a6ddcb-2be3-493e-aad2-c32280d9e5e1', '11', '2018-08-11 09:36:11', '0');
INSERT INTO `team_member` VALUES ('74', '6e80805d-fa1b-474b-b848-06de08746395', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, '66a6ddcb-2be3-493e-aad2-c32280d9e5e1', '11', '2018-08-11 09:36:11', '0');
INSERT INTO `team_member` VALUES ('75', '6704e7b6-b638-4d39-83b2-dd2127f75425', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, '66a6ddcb-2be3-493e-aad2-c32280d9e5e1', '11', '2018-08-11 09:36:11', '0');
INSERT INTO `team_member` VALUES ('76', '017a856a-fcba-4139-ae0c-8a6ae24bf213', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, '66a6ddcb-2be3-493e-aad2-c32280d9e5e1', '11', '2018-08-11 09:36:11', '0');
INSERT INTO `team_member` VALUES ('77', '1c1c81cd-c6d7-4dc3-86b8-56ed740c948b', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, '66a6ddcb-2be3-493e-aad2-c32280d9e5e1', '11', '2018-08-11 09:36:11', '0');
INSERT INTO `team_member` VALUES ('78', '39813e32-1602-448b-bb03-7aa654dabe62', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, '66a6ddcb-2be3-493e-aad2-c32280d9e5e1', '11', '2018-08-11 09:36:11', '0');
INSERT INTO `team_member` VALUES ('79', '12251427-a830-47e7-9499-8831b73f5a5b', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, '66a6ddcb-2be3-493e-aad2-c32280d9e5e1', '11', '2018-08-11 09:36:11', '0');
INSERT INTO `team_member` VALUES ('80', '5c06266e-1026-4fca-b5f7-fc6f183a5f83', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, '66a6ddcb-2be3-493e-aad2-c32280d9e5e1', '11', '2018-08-11 09:36:11', '0');
INSERT INTO `team_member` VALUES ('81', '41e58806-9836-4a5a-81be-a5a7f2dbfafa', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, '66a6ddcb-2be3-493e-aad2-c32280d9e5e1', '11', '2018-08-11 09:36:11', '0');
INSERT INTO `team_member` VALUES ('82', '912c685b-f43e-4d7e-bba4-7e5f6729bf26', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, '66a6ddcb-2be3-493e-aad2-c32280d9e5e1', '11', '2018-08-11 09:36:11', '0');
INSERT INTO `team_member` VALUES ('83', '929301d8-f3e8-44d1-b411-c181e1c4b267', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, '66a6ddcb-2be3-493e-aad2-c32280d9e5e1', '11', '2018-08-11 09:36:11', '0');
INSERT INTO `team_member` VALUES ('84', 'f9a7c0a9-ad0c-4bd4-9d30-6e96a188f64f', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, '66a6ddcb-2be3-493e-aad2-c32280d9e5e1', '11', '2018-08-11 09:36:11', '0');
INSERT INTO `team_member` VALUES ('85', 'ad45a96f-7274-4bb5-aa5a-92e3ebc01e5e', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, '66a6ddcb-2be3-493e-aad2-c32280d9e5e1', '11', '2018-08-11 09:36:11', '0');
INSERT INTO `team_member` VALUES ('86', '68ec48a7-d694-41ce-b76c-b2cfaf055a0c', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, '66a6ddcb-2be3-493e-aad2-c32280d9e5e1', '11', '2018-08-11 09:36:11', '0');

-- ----------------------------
-- Table structure for `team_teach_video`
-- ----------------------------
DROP TABLE IF EXISTS `team_teach_video`;
CREATE TABLE `team_teach_video` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `video_id` varchar(64) NOT NULL COMMENT '视频id',
  `team_id` varchar(64) NOT NULL COMMENT '队id',
  `name` varchar(255) DEFAULT NULL COMMENT '视频名称',
  `description` text COMMENT '视频描述',
  `video` varchar(255) DEFAULT NULL COMMENT '视频地址',
  `creator_id` varchar(64) NOT NULL DEFAULT '',
  `create_time` datetime DEFAULT NULL,
  `delete_status` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `video_id` (`video_id`) USING BTREE,
  KEY `team_id` (`team_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of team_teach_video
-- ----------------------------

-- ----------------------------
-- Table structure for `user`
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `uid` varchar(255) NOT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  `user_email` varchar(255) DEFAULT NULL,
  `user_password` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `phone` varchar(255) NOT NULL,
  `company` varchar(255) DEFAULT NULL,
  `department` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '0：无效用户 1：有效, -1 预分配uid用户',
  `creator_id` varchar(64) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `active_time` datetime DEFAULT NULL COMMENT '激活时间',
  `delete_status` tinyint(4) NOT NULL DEFAULT '0',
  `club_id` varchar(255) DEFAULT NULL,
  `school_id` varchar(255) DEFAULT NULL,
  `team_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uid` (`uid`) USING BTREE,
  KEY `phone` (`phone`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('1', '10001', 'A', 'a@xp.com', '123123', 'a', '13426233960', 'xxxxxxxxx', null, null, '1', null, null, null, '0', null, null, null);
INSERT INTO `user` VALUES ('2', '10002', 'B', 'b@xp.com', '123123', 'b', '12345678911', null, '1', 'ceo', '1', null, '2018-07-23 11:35:52', '2018-07-23 11:35:52', '1', null, null, null);
INSERT INTO `user` VALUES ('6', '10003', 'C', 'c@xp.com', '123123', 'c', '12345678912', null, '1', null, '1', null, null, null, '1', null, null, null);
INSERT INTO `user` VALUES ('7', '10004', 'D', 'd@xp.com', '123123', 'd', '12345678913', null, '1', null, '1', null, null, null, '1', null, null, null);
INSERT INTO `user` VALUES ('8', '61b354ff-02ea-4d98-8159-4dc61958defc', 'ao', 'tvrrdfn@126.com', '123123', 'ao', '13811532737', null, null, null, '1', null, null, null, '0', null, null, null);
INSERT INTO `user` VALUES ('10', 'c5f7522f-fbbd-4b1c-b473-ead48c9baf34', null, null, null, 'test', '13412341234', null, '1', null, '1', null, '2018-07-28 23:23:32', '2018-07-28 23:23:32', '1', null, null, null);
INSERT INTO `user` VALUES ('11', 'a101f16b-3847-4a12-97d5-150d5cc64e7d', null, null, null, 'da', '12312341234', null, '1', null, '1', null, '2018-07-29 10:44:50', '2018-07-29 10:44:50', '1', null, null, null);
INSERT INTO `user` VALUES ('14', 'fe791cb4-a2fb-4826-8b8d-0e4e7337603a', null, null, null, 'fox', '13811578499', null, '1', null, '1', null, '2018-07-29 11:56:27', '2018-07-29 11:56:27', '0', null, null, null);
INSERT INTO `user` VALUES ('16', 'eb3e034d-372d-4841-a8d3-83a63fc21880', null, null, null, '希哥', '13811953661', null, '1', null, '1', null, '2018-07-29 12:01:26', '2018-07-29 12:01:26', '0', null, null, null);
INSERT INTO `user` VALUES ('18', '4416f3dc-bb71-49d8-9c52-ca9d4f2c9c8f', null, null, null, '【勿删】test-club', '13000000001', null, '11685c71-3576-4c3c-bc94-a9d4c7132122', null, '1', null, '2018-07-29 15:15:36', '2018-07-29 15:15:36', '0', null, null, null);
INSERT INTO `user` VALUES ('19', 'f0adaf7d-6e64-4c61-90a9-674414fdaed7', null, null, null, '陈逸非', '18610111856', null, '1', null, '1', null, '2018-07-29 15:41:39', '2018-07-29 15:41:39', '0', null, null, null);
INSERT INTO `user` VALUES ('20', 'b42d88a1-6ad1-4831-8ecf-56d004c166d3', null, null, null, '杜逸斌', '18600233952', null, '1', null, '1', null, '2018-07-29 16:33:45', '2018-07-29 16:33:45', '0', null, null, null);
INSERT INTO `user` VALUES ('21', '7afbaddd-4b9e-4794-abfd-6a0a191a53fd', null, null, null, '【勿删】test-school', '13000000002', null, '11685c71-3576-4c3c-bc94-a9d4c7132122', null, '1', null, '2018-07-31 09:02:40', '2018-07-31 09:02:40', '0', null, null, null);
INSERT INTO `user` VALUES ('23', '82d82ad1-463f-4760-999d-104e78114f42', null, null, null, '丽娜', '18610430866', null, '1', null, '1', null, '2018-07-31 15:03:47', '2018-07-31 15:03:47', '0', null, null, null);
INSERT INTO `user` VALUES ('24', '3fec4ec6-2636-4c4e-a483-348ddd084246', null, null, null, '【勿删】test-team', '13000000003', null, '11685c71-3576-4c3c-bc94-a9d4c7132122', null, '1', null, '2018-07-31 21:18:12', '2018-07-31 21:18:12', '0', null, null, null);
INSERT INTO `user` VALUES ('25', '47fbf3b1-861a-40fc-826b-d506b17bf7b8', null, null, null, '121xxxx', '13141231234', null, 'bb9db48c-4262-4fe8-803e-cd7cde35f606', null, '1', null, '2018-08-03 21:02:36', '2018-08-03 21:02:36', '0', null, null, null);
INSERT INTO `user` VALUES ('26', '972825f6-e672-4ff7-abce-60fef8a818af', null, null, null, '11', '13412341234', null, 'club-1', null, '1', null, '2018-08-03 21:04:41', '2018-08-03 21:04:41', '0', null, null, null);
INSERT INTO `user` VALUES ('27', 'c42ed1c3-2d6a-44ef-92c1-a0f9fbf97cfd', null, null, null, '12', '12131313131', null, 'club-1', null, '1', null, '2018-08-03 21:50:01', '2018-08-03 21:50:01', '0', null, null, null);
INSERT INTO `user` VALUES ('28', '240e77d7-8329-459b-8497-1fead433bb52', null, null, null, 'test', '13312341234', null, 'bb9db48c-4262-4fe8-803e-cd7cde35f606', null, '1', null, '2018-08-05 09:31:44', '2018-08-05 09:31:44', '0', null, null, null);
INSERT INTO `user` VALUES ('29', 'b8d296bd-01a1-4695-8dfa-db48cfd3a825', null, null, null, '1', '13811231234', null, 'club-1', null, '1', null, '2018-08-05 16:23:52', '2018-08-05 16:23:52', '0', null, null, null);
INSERT INTO `user` VALUES ('30', 'a43071b7-cb70-4d5a-8bc7-ed31f23e716f', null, null, null, '11', '13412341244', null, 'club-1', null, '1', null, '2018-08-07 14:29:47', '2018-08-07 14:29:47', '0', null, null, null);
INSERT INTO `user` VALUES ('31', 'f07b747c-89f3-4426-b571-e3305073a656', null, null, null, '1212121', '12312341255', null, 'first', null, '1', null, '2018-08-07 16:31:18', '2018-08-07 16:31:18', '0', null, null, null);
INSERT INTO `user` VALUES ('32', 'f5b7bcdb-3d7e-4466-8b95-82548cd86119', null, null, null, '121', '12311112222', null, 'first', null, '1', null, '2018-08-07 16:33:20', '2018-08-07 16:33:20', '0', null, null, null);
INSERT INTO `user` VALUES ('33', '68d9e5b8-854a-481e-a0e4-aaf3a98d3749', null, null, null, 'test', '13011231234', null, '79eb5d6c-ed31-40dd-8131-8d4128309cc5', null, '1', null, '2018-08-07 17:38:14', '2018-08-07 17:38:14', '0', null, null, null);
